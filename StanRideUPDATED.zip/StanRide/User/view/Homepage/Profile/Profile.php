
<div style="margin-bottom: 8%">
</div>
      
      
    <!-- Team -->
    <section class="bg-light" id="team">
        
         <!--  <?php
        if($update == "ok"){
                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Updated..</div>';
                }
      ?> -->
      
      <div class="container">
       
        <div class="row">
          <div class="col-sm-6">

            <div class="team-member">
              <img class="mx-auto rounded-circle" src="<?php echo $userInfo['user_img'];?>" alt="">
              <h4><?php echo $userInfo['user_fname']." ".$userInfo['user_lname'];?></h4>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="">
              
              <p class="text-muted">
                  <?php echo "<strong>Gender:</strong> ".$userInfo['user_gender'];?> <br>
                  <?php echo "<strong>Job:</strong> ".$userInfo['user_work'];?> <br>
                  <?php echo "<strong>Contact:</strong> ".$userInfo['user_contact'];?> <br>
                  <?php echo "<strong>Address:</strong> ".$userInfo['user_address'];?> <br>
                  <?php echo "<strong>Email:</strong> ".$userInfo['user_email'];?> <br>
                  
              </p>
              <ul class="list-inline social-buttons">
                <li class="list-inline-item">
                  <a class="btn btn-danger" href="index.php?homepage=Profile/ChangeProfile">
                    <i class="fa fa-edit"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-danger" href="index.php?homepage=Profile/ChangePassword">
                    <i class="fa fa-lock"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-danger" href="#">
                    <i class="fa fa-remove"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
    
        </div>
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <p class="large text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Clients -->