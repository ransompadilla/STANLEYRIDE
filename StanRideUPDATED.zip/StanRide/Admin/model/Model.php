<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterAdmin($data){
            $query = "INSERT INTO admin(admin_name, admin_address, admin_email, admin_password, admin_img) VALUES(?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
        public function RegisterApplicant($data){
            $query = "INSERT INTO applicant_info(app_lname, app_fname, app_age, app_gender, app_address, app_contact, app_img, app_resume, app_status,active) VALUES(?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function GetVehicleWithUser(){
            $query = "SELECT u.*, v.* FROM user u, vehicle v WHERE v.user_id=u.user_id";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function getUserInformation($data){
            $query = "SELECT * FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET SUBSCRIBE NOTIF
        public function GetSubscribeNotif(){
            $query = "SELECT v.*, vpc.*, s_type.*, vp.*, u.* FROM vehicle v, vehicle_part_change vpc, service_type s_type, vehicle_part vp, user u where vpc.v_id=v.v_id and vpc.v_service_type_id=s_type.v_service_type_id and vpc.v_part_id=vp.v_part_id and vpc.user_id=u.user_id and v.v_subscribe=1 and vpc.pending=0 and vpc.notif_subs=1  ORDER BY vpc.change_date DESC";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET MY VEHCLE DETAILS
        public function GetMyVehicle($data){
            $query = "SELECT v.*, b.*, s_type.* FROM vehicle v, brand b, service_type s_type WHERE v.user_id=$data and v.v_service_type_id = s_type.v_service_type_id and v.v_brand_id=b.brand_id ORDER BY v_create_date DESC";
            
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
         public function GetMyVehicleDetails($data){
            $query = "SELECT v.*, b.*, s_type.* FROM vehicle v, brand b, service_type s_type WHERE v.v_id=? and v.v_service_type_id = s_type.v_service_type_id and v.v_brand_id=b.brand_id ORDER BY v_create_date DESC";
            
            $rows = $this->crud->Select($query, $data);
            return $rows;
        }
        public function GetPartChangeDetails($v_id, $vpart_id){
            $query = "SELECT vpc.*, vst.* FROM vehicle_part_change vpc, service_type vst WHERE vpc.v_id=$v_id and vpc.v_service_type_id = vst.v_service_type_id and vpc.v_part_id = $vpart_id and vpc.pending=0 ORDER BY vpc.change_date DESC;";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetPartChangeLastDate($data){
            $query = "SELECT vpc.*, vst.* FROM vehicle_part_change vpc, service_type vst WHERE vpc.v_id=? and vst.v_service_type_id = vpc.v_service_type_id and vpc.v_part_id = ? ORDER BY vpc.change_date DESC;";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function GetPartChangeGetLastDate($data){
            $query = "SELECT change_date FROM vehicle_part_change WHERE v_id=? and v_part_id = ? and pending=0 ORDER BY change_date DESC;";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function GetVehicleParts(){
            $query = "SELECT * FROM vehicle_part";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetVehiclePartByID($data){
            $query = "SELECT * FROM vehicle_part WHERE v_part_id=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function GetVehicleByID($data){
            $query = "SELECT * FROM vehicle WHERE v_id=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        //SEND MESSAGE
        public function SendMessages($data){
         $query = "INSERT INTO message(tr_id, sender, messages) VALUES(?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set cust_email=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        public function ChangePassword($table,$data){
            $query = "UPDATE $table set cust_password=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        //VALIDATE LOGIN
        public function ValidateAdminLogin($data){
            $query = "SELECT * FROM admin where admin_email=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function Admin_Logout(){
            if(isset($_COOKIE['admin_id'])){
                setcookie("admin_id",$_COOKIE['admin_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        //USER SIDE

        public function getUserNameByID($data){
            $name=null;
            $query = "SELECT user_name FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['user_name'];
            }
            return $name;
        }
        public function getUserImgByID($data){
            $img=null;
            $query = "SELECT user_img FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['user_img'];
            }
            else $img=null;
            return $img;
        }
        //
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_name FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_name'];
            }
            return $name;
        }
        public function getAdminImgByID($data){
            $img=null;
            $query = "SELECT admin_img FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['admin_img'];
            }
            else $img=null;
            return $img;
        }
        public function getApplicant(){
          $query = "SELECT * FROM applicant_info WHERE active=1 and approve=1;";
          $row = $this->crud->SelectAll($query);
          return $row;  
        }
        public function getApplicantUpApprove(){
          $query = "SELECT * FROM applicant_info WHERE active=1 and approve=0;";
          $row = $this->crud->SelectAll($query);
          return $row;  
        }
        public function getPortfolio($data){
            $query = "SELECT * FROM applicant_info WHERE app_id=? and active=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //TRANSACTIONS
        public function getTransactionsNotif(){
            $query = "SELECT a.*, t.*, u.* FROM  transaction t, applicant_info a, user u WHERE t.app_id=a.app_id and t.user_id=u.user_id and a.active=1 and a.approve=1 ORDER BY date_trans DESC";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getTransactionsNotifCount(){
            $query = "SELECT notif FROM  transaction WHERE notif=0;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getTransactions($data){
            $query = "SELECT a.*, t.* FROM applicant_info a JOIN transaction t ON t.app_id=a.app_id WHERE t.tr_id=? and a.active=1 and a.approve=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }

        public function getMessages($data){
            $query = "SELECT * FROM message WHERE tr_id=$data ORDER BY date DESC;";
            $row = $this->crud->SelectAll($query);
            return $row;           
        }
        //UPDATE TRANSACTION
        public function ApproveApplicant($data){
            $query = "UPDATE applicant_info SET approve=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateNotifTransaction($data){
            $query = "UPDATE transaction SET admin_id=?, notif=? WHERE tr_id=?;";
            $this->crud->Update($query,$data);
        }
        //UPDATE APPLicANT
        public function UpdateAppStatus($data){
            $query = "UPDATE applicant_info SET app_status=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateApplicant($data){
            $query = "UPDATE applicant_info SET app_lname=?,app_fname=?,app_age=?, app_gender=?, app_address=?, app_contact=?, app_img=?, app_resume=?, app_status=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function DeleteApplicant($data){
            $query = "UPDATE applicant_info SET active=0 WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        //SUBSCRIBE
        public function SubscribeUser($data){
            $query = "UPDATE user SET subscribe=1 WHERE user_id=?";
            $this->crud->Update($query,$data);
        }
        public function SubscribeVehicle($data){
            $query = "UPDATE vehicle SET v_subscribe=1 WHERE v_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateNotifSubs($data){
            $query = "UPDATE vehicle_part_change SET notif_subs=? WHERE v_part_change_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateNotifVehicle($data){
            $query = "UPDATE vehicle SET v_notif=? WHERE v_id=?";
            $this->crud->Update($query,$data);
        }
	}
?>