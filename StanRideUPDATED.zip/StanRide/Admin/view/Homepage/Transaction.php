<div class="container">
  
  <!-- Left-aligned media object -->
  <?php
    $transaction=null;
     if(isset($_GET['transaction_no'])){

        $transaction = $this->model->getTransactions(array($_GET['transaction_no']));
     }
    if(count($transaction) > 1){
                    $message = $this->model->getMessages($transaction['tr_id']); 
      echo '
      <div style="margin-top: 10%; color: #aeaeae;">

  <div class="media" >
    <div class="media-left">
      <img src="'.$transaction['app_img'].'" class="media-object" style="width:100px; height: 100px;">
    </div>
    <div class="media-body" style="margin-left: 10px;">
      <h5 class="media-heading" > '.$transaction['app_lname'].", ".$transaction['app_fname'].'</h5>
      <p> '.$transaction['message'].'<br>';
        $d = strtotime($transaction['date_trans']);
        $date = Date('F j, Y h:i A',$d);
        echo "<i class='small text-muted'>$date";
      echo '</p>
    </div>
  </div>
  <hr>
  <div style="margin-left: 10%; color: #aeaeae;">';
  foreach ($message as $m) {

        if($m['sender'] != $transaction['user_id']){
          $imgs = $this->model->getAdminImgByID(array($m['sender']));
          $names = $this->model->getAdminNameByID(array($m['sender']));
        }
        else{
          $imgs = $this->model->getUserImgByID(array($m['sender']));
          $names = $this->model->getUserNameByID(array($m['sender']));
        }

     
      echo '<div class="media" >
        <div class="media-left">
          <img src="'.$imgs.'" class="media-object" style="width:60px; height: 60px;">
        </div>
        <div class="media-body" style="margin-left: 10px;">
          <h5 class="media-heading" > '.$names.'</h5>
          <p> '.$m['messages'].'<br>';
            $d = strtotime($m['date']);
            $date = Date('F j, Y h:i A',$d);
            echo "<i class='small text-muted'>$date</i>";
          echo '</p>
        </div>
      </div><hr>';
  }
  echo '</div>
  <form method="POST">
  <p>
  <input type="hidden" name="tr_id" value="'.$transaction['tr_id'].'">
  <input type="hidden" name="sender" value="'.$admin_id.'">
  <img src="'.$img.'" style="width: 40px;height:40px;margin-top: -35px;">
  <textarea class="form" name="message" style="width: 70%;height:40px;" placeholder="Write messages..."></textarea>
  <button type="submit" name="send_message" class="btn btn-default" style="margin-top: -33px;">Send</button>
  </p>
  </form>

  </div>
      ';

    }
    else{
      echo '<div style="margin-top: 10%;" class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> NO TRANSACTIONS..</div>';
    }
    
  ?>
  
</div>
