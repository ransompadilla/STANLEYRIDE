<header class="masthead">
      <div class="container">
        <div class="intro-text">
          <div class="intro-lead-in">Hi! <?=$name;?></div>
          <div><img src="<?=$img;?>"></div><br>
          <div class="intro-lead-in">Welcome To Stanley Ride!</div>
          <div class="intro-heading">It's Nice To Meet You</div>
          
        </div>
      </div>
      
    </header>