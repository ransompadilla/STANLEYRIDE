<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterUser($data){
            $query = "INSERT INTO user(user_name, user_address, user_contact, user_company, user_email, user_password,user_img) VALUES(?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
        public function Transaction($data){
            $query = "INSERT INTO transaction(app_id,user_id,message,notif) VALUES(?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function RegisterApplicant($data){
            $query = "INSERT INTO applicant_info(app_lname, app_fname, app_age, app_gender, app_address, app_contact, app_img, app_resume, app_status,active,user_id,approve) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set cust_email=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        public function ChangePassword($table,$data){
            $query = "UPDATE $table set cust_password=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        //VALIDATE LOGIN
        public function ValidateUserLogin($data){
            $query = "SELECT * FROM user where user_email=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function User_Logout(){
            if(isset($_COOKIE['user_id'])){
                setcookie("user_id",$_COOKIE['user_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        public function getUserInformation($data){
             
            $query = "SELECT * FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            
            return $row;
        }
        public function getUserNameByID($data){
            $name=null;
            $query = "SELECT user_name FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['user_name'];
            }
            return $name;
        }
        public function getUserImgByID($data){
            $img=null;
            $query = "SELECT user_img FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['user_img'];
            }
            else $img=null;
            return $img;
        }
        //AMDIN SIDE
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_name FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_name'];
            }
            return $name;
        }
        public function getAdminImgByID($data){
            $img=null;
            $query = "SELECT admin_img FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['admin_img'];
            }
            else $img=null;
            return $img;
        }
        //
        public function getAvailableGuard(){
            $query = "SELECT * FROM applicant_info WHERE app_status=0 and active=1 and approve=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //////applicant
        public function getMaxIDApplicant(){
            $query = "SELECT max(app_id) as max FROM applicant_info;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getApplicantInfo($data){
            $query = "SELECT * FROM applicant_info WHERE app_id=? and active=1 and approve=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }

        public function getPortfolio($data){
            $query = "SELECT * FROM applicant_info WHERE user_id=$data and active=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getTransactions($data){
            $query = "SELECT a.*, t.*, m.*, ad.* FROM applicant_info a, transaction t, message m, admin ad WHERE t.app_id=a.app_id and t.tr_id=m.tr_id and m.sender=ad.admin_id and t.user_id=$data  and a.active=1 and a.approve=1 order by m.date DESC";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getTransactionWith($data){
            $query = "SELECT a.*, t.* FROM applicant_info a JOIN transaction t ON t.app_id=a.app_id WHERE t.tr_id=? and a.active=1 and a.approve=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function getMessageNotif($data){
            $query = "SELECT status FROM  message WHERE status=0 and sender=$data;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //MESSAGES
        public function getMessages($data){
            $query = "SELECT * FROM message WHERE tr_id=$data ORDER BY date desc;";
            $row = $this->crud->SelectAll($query);
            return $row;           
        }

        //SEND MESSAGE
        public function SendMessages($data){
         $query = "INSERT INTO message(tr_id, sender, messages) VALUES(?,?,?)";
            $this->crud->Insert($query,$data);
        }
        //UPDATE
        public function UpdateApplicant($data){
            $query = "UPDATE applicant_info SET app_lname=?,app_fname=?,app_age=?, app_gender=?, app_address=?, app_contact=?, app_img=?, app_resume=?, app_status=? WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
        public function UpdateApplicantStatus($data){
            $query = "UPDATE applicant_info SET app_status=? WHERE app_id=?;";
            $this->crud->Update($query,$data);
        }
        public function DeleteApplicant($data){
            $query = "UPDATE applicant_info SET active=0 WHERE app_id=?";
            $this->crud->Update($query,$data);
        }
	}
?>