<!DOCTYPE html>
<html>
<head>
	<?php include "model/Bootstrap.php"; ?>
  <script src="../Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="../Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
    //alert("asdf");
    $('.appendhere').hide();
    $('.appendInput').change(function(){
      var value = $(this).val();
      if(value==2){
      $('.appendhere').show();
      }
      else if(value==1){
      $('.appendhere').hide();
      }
    });
   });
  
  </script>
  <style type="text/css">
      #notif:hover{background-color: #d0d0d0;}
      #notif a {color: #000000; text-decoration: none;}
      #notif{padding:5px;}

      .user-details {position: relative; padding: 0;}
      .user-details .user-image {position: relative;  z-index: 1; width: 100%; text-align: center;}
       .user-image img { clear: both; margin: auto; position: relative;}
       .user-info-block{margin-top: 70px}
      .user-details .user-info-block {width: 100%; position: absolute; top: 55px; background: rgb(255, 255, 255); z-index: 0; padding-top: 35px;}
       .user-info-block .user-heading {width: 100%; text-align: center; margin: 10px 0 0;}
       .user-info-block .navigation {float: left; width: 100%; margin: 0; padding: 0; list-style: none; border-bottom: 1px solid #428BCA; border-top: 1px solid #428BCA;}
        .navigation li {float: left; margin: 0; padding: 0;}
         .navigation li a {padding: 20px 30px; float: left;}
         .navigation li.active a {background: #428BCA; color: #fff;}
       .user-info-block .user-body {float: left; padding: 5%; width: 90%;}
        .user-body .tab-content > div {float: left; width: 100%;}
        .user-body .tab-content h4 {width: 100%; margin: 10px 0; color: #333;}
    </style>
</head>
<body id="page-top" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Stanley Ride</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Portfolio">Portfolio</a>
            </li>

            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Post">Post</a>
            </li>
            <li class="nav-item">
            <div class="dropdown">
            
            <?php $count = count($this->model->getMessageNotif($user_id));?>
              <a class="nav-link js-scroll-trigger dropdown-toggle" data-toggle="dropdown" href="#"><span class="fa fa-globe"><i class="badge"><?=$count;?></i></span>
              </a>
              <ul class="dropdown-menu" style="padding: 10px; width: 300px; margin-left: -20px;  overflow: auto; height: 500px;">
              <?php
                foreach ($transaction as $tr) {
                  echo '<li style="background-color:#e0e0e0;" id="notif"><a href="index.php?homepage=Transaction&transaction_no='.$tr['tr_id'].'">
                    <p class="pull-right"><img src="'.$tr['app_img'].'" style="width:30px; height:30px;"><br>
                      <i class="small text-muted">'.$tr['app_lname'].'</i></p>
                      <img src="'.$tr['admin_img'].'" style="width:40px; height:40px;"> 
                      '.$tr['admin_name'].' <br> <i class="small text-muted" style="margin-left:40px;">have message on your post</i> 
                      
                      </a></li><hr>';
                }
              ?>
              </ul>
            </div>
            </li>
            <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="index.php?homepage=Profile/Profile">
              <img class="img-circle" src="<?=$img;?>" width="20">
              <?=$name;?>
            </a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?logout=1">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

