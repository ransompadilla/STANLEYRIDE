<form class="login-form" name="AuthForm" method="POST"  onsubmit="return validatePassword();"  enctype="multipart/form-data">  
  <p id="validatePassword"></p>    
        <p>
              <?php 
                if($flag == 1){
                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Added..</div>';
                }
                
              ?>
              
            </p>  
        <div class="row" >
            
            
            
            <div class="col-md-3"></div>
            <div class="col-md-6">
                  <label><h1>Change Password</h1> </label>
                  

                  <div class="form-group">
                    <input class="form-control" name="password" type="password" placeholder="Your Password *" required="">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="c_pass" type="password" placeholder="Retype Password *" required="">
                    <p class="help-block text-danger"></p>
                  </div>
                  <button type="submit" name="register_user" class="btn btn-info" style="width: 49%">
                    Submit</button>
                  <a href="index.php" class="btn btn-danger" style="width: 49%">
                    Cancel</a>
                </div>
        </div>
      </form>