<div style="margin-top: 10%;">
<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-12 user-details">
            <div class="user-image">
                <img src="http://www.gravatar.com/avatar/2ab7b2009d27ec37bffee791819a090c?s=100&d=mm&r=g" alt="Karan Singh Sisodia" title="Karan Singh Sisodia" class="img-circle" style="width: 170px;">
            </div>
            <div class="user-info-block">
                <div class="user-heading">
                    <h3><?php echo $userInfo['user_name']?></h3>
                    <span class="help-block"><?php echo $userInfo['user_address']?></span>
                </div>
                <ul class="navigation">
                    <li class="active">
                        <a data-toggle="tab" href="#information">
                            <span class="fa fa-user"></span>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#settings">
                            <span class="fa fa-cog"></span>

                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#email">
                            <span class="fa fa-envelope"></span>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#events">
                            <span class="fa fa-calendar"></span>
                        </a>
                    </li>
                </ul>
                <div class="user-body">
                    <div class="tab-content">
                        <div id="information" class="tab-pane active">
                            <h4>Account Information</h4>

                          <h6>NAME: <?php echo $userInfo['user_name']?></h6>
                          <h6>ADDRESS: <?php echo $userInfo['user_address']?></h6>
                          <h6>NAME: <?php echo $userInfo['user_contact']?></h6>
                          <h6>NAME: <?php echo $userInfo['user_company']?></h6>
                          <h6>NAME: <?php echo $userInfo['user_email']?></h6>

                        </div>
                        <div id="settings" class="tab-pane">
                            <h4>Settings</h4>
                            <a  data-toggle="tab" href="#change-details" class="btn btn-success">Change Details</a>
                            <a  data-toggle="tab" href="#change-password" class="btn btn-danger">Change Password</a>

                         <div class="tab-content">
                              <div id="change-details" class="tab-pane">
                                <?php include "view/Homepage/Profile/ChangeProfile.php";?>
                              </div>
                              <div id="change-password" class="tab-pane"> <?php include "view/Homepage/Profile/ChangePassword.php";?>
                              </div>
                            </div>
                          </div>
            
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>