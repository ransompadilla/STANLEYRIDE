<?php
	include_once("model/Model.php");
	class Controller{
		public	$model;
		public	function __construct(){		
			$this->model = new Model();
		}
		public function invoke(){
			 $this->Delete();
			 $this->Update();
			//  //$this->Retrieve();
			$this->Download();
		    $this->Create();
		    $this->Logout();
		    $this->ValidateLogin();
			 

			
			$this->AUTH();
		}
		
		public function AUTH(){
			if(isset($_GET['auth'])){
				$auth = rtrim($_GET['auth'], '/');
				include 'view/Auth/'.$auth.'.php';
			}
			else if(isset($_GET['homepage'])){
				$this->Retrieve(); 	
			 }
			 else{
			
				include 'view/index.php';
				
			}	
			
		}
		//
		public function ValidateLogin(){
			if(isset($_POST['login_user'])){
				$email = $_POST['email'];
				$password = $_POST['password'];
				$row = $this->model->ValidateUserLogin(array($email,$password));
				if(count($row) > 1){
                setcookie("user_id", $row['user_id'], time() + 86400, "/"); // 86400 = 1 day
                header("Location: index.php?homepage=Home");
            }
            else{
                header('location: index.php?auth=Authentication');
            }
			}
		}
		public function Logout(){
			if(isset($_GET['logout'])){
				$this->model->User_Logout();
			}
		}
		//
		public function Create(){
			
			//REGISTER STAFF
			if(isset($_POST['register_user'])){
				
				$name = $_POST['name'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];
				$company = $_POST['company'];
				$email = $_POST['email'];
				$password = $_POST['password'];

				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->RegisterUser(array($name,$address,$contact,$company, $email, $password, $target_file));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?auth=Register");
			}
			//HIRE

			if(isset($_POST['hire'])){
				$user_id = $_POST['user_id'];
				$status = $_POST['status'];
				$app_id = $_POST['app_id'];
				$message = $_POST['message'];
				$this->model->UpdateApplicantStatus(array($status, $app_id));
				$this->model->Transaction(array($app_id, $user_id, $message, 0));
			 	header("Location: index.php?homepage=Portfolio");
			}

			// APplicants
			if(isset($_POST['register_applicant'])){
				$user_id = $_POST['user_id'];
				$lname = $_POST['lname'];
				$fname = $_POST['fname'];
				$age = $_POST['age'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];

				$folder = "../Bootstrap/file/";
				$temp = explode(".", $_FILES["uploaded"]["name"]);
				$newfilename = round(microtime(true)).'.'. end($temp);
				$db_path ="$folder".$newfilename  ;
				$listtype = array(
				'.doc'=>'application/msword',
				'.docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'.rtf'=>'application/rtf',
				'.pdf'=>'application/pdf'); 
				if ( is_uploaded_file( $_FILES['uploaded']['tmp_name'] ) ){
					if($key = array_search($_FILES['uploaded']['type'],$listtype)){
						if (move_uploaded_file($_FILES['uploaded']  ['tmp_name'],"$folder".$newfilename)){
						echo "The file ". basename( $_FILES["uploaded"]["name"]). " has been uploaded.";
						}
					}
					else {
					echo "File Type Should Be .Docx or .Pdf or .Rtf Or .Doc";
					}
				}
				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->RegisterApplicant(array($lname, $fname,$age, $gender, $address, $contact, $target_file, $db_path,0,1,$user_id,0));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?homepage=Post");
			}
			if(isset($_POST['send_message'])){
				$tr_id = $_POST['tr_id'];
				$sender = $_POST['sender'];
				$message = $_POST['message'];

				$this->model->SendMessages(array($tr_id,$sender,$message));
				header("Location: index.php?homepage=Transaction&transaction_no=$tr_id");
			}
		}
		public function Retrieve(){
				if(isset($_COOKIE['user_id'])){
					date_default_timezone_set('Asia/Manila');
			        $user_id=$_COOKIE['user_id'];
			         $name = $this->model->getUserNameByID(array($user_id));
			         $img = $this->model->getUserImgByID(array($user_id));
			         $available_guard = $this->model->getAvailableGuard();
			         $transaction = $this->model->getTransactions($user_id);
			         $portfolio = $this->model->getPortfolio($user_id);
			         $max = $this->model->getMaxIDApplicant();
			         $userInfo = $this->model->getUserInformation(array($user_id));
			         foreach ($max as $m) {$maximum = $m['max'];}
			        if(isset($_GET['homepage'])){
			        	
			        	$homepage = null;
							$flag = rtrim($_GET['homepage'], '/');
							$page = array("Home","Profile/Profile", "Profile/ChangeProfile", "Profile/ChangePassword","Portfolio", "Portfolio/Update", "Transaction", "Post");
							for($i=0;$i<count($page);$i++){
								if($flag == $page[$i]){
									$homepage = $flag;
										include 'view/Homepage/UserHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/UserFooter.php';
									
								}
								else $homepage = $homepage;
						}
					 		
			 		
						 		
					}
				}
		    else{
		      header('location: index.php');
		    }				
		}
		public function Update(){
			//
			if(isset($_POST['update_applicant'])){
				$app_id = $_POST['app_id'];
				$lname = $_POST['lname'];
				$fname = $_POST['fname'];
				$age = $_POST['age'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];
				$status = $_POST['status'];

				$folder = "../Bootstrap/file/";
				$temp = explode(".", $_FILES["uploaded"]["name"]);
				$newfilename = round(microtime(true)).'.'. end($temp);
				$db_path ="$folder".$newfilename  ;
				$listtype = array(
				'.doc'=>'application/msword',
				'.docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'.rtf'=>'application/rtf',
				'.pdf'=>'application/pdf'); 
				if ( is_uploaded_file( $_FILES['uploaded']['tmp_name'] ) ){
					if($key = array_search($_FILES['uploaded']['type'],$listtype)){
						if (move_uploaded_file($_FILES['uploaded']  ['tmp_name'],"$folder".$newfilename)){
						echo "The file ". basename( $_FILES["uploaded"]["name"]). " has been uploaded.";
						}
					}
					else {
					echo "File Type Should Be .Docx or .Pdf or .Rtf Or .Doc";
					}
				}
				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->UpdateApplicant(array($lname, $fname,$age, $gender, $address, $contact, $target_file, $db_path,$status,$app_id));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?homepage=Portfolio");
			}
			//Change Email
			if(isset($_POST['change_staff_email'])){
		    $emp_id = $_POST['emp_id'];
			$email = $_POST['email'];
			$password = $_POST['password'];
		    $data = array($email,$emp_id);
		    $check_email = $this->model->CheckStaffEmail(array($email));
		    $check_pass = $this->model->CheckStaffPassword(array($emp_id, $password));
	        //setcookie("emp_email", $email, time() + 86400, "/");
	        if($check_email == NULL && $check_pass == "Checked"){
				$this->model->ChangeStaffEmail($data);
				setcookie("update", "ok", time() + 5, "/");
		        setcookie("emp_email", $email, time() + 86400, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
			else{
				setcookie("update", "used", time() + 5, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
		}
		//ChangePassword
		if(isset($_POST['change_staff_password'])){
		    $emp_id = $_POST['emp_id'];
			$password = $_POST['password'];
		    $data = array($password,$emp_id);
	        	$this->model->ChangeStaffPassword($data);
				setcookie("update", "ok", time() + 5, "/");
				header('Location: index.php?homepage=Profile&next=3');
			
		}

		}
		public function Delete(){
			if(isset($_GET['id'])){
				$id=$_GET['id'];
					$this->model->DeleteApplicant(array($id));
					header('Location: index.php?homepage=Portfolio');	
			}
		}
		public function Download(){
			if(isset($_GET['file'])){
				$file = $_GET['file'];
				header('Content-Description: File Transfer');
			    header('Content-Type: application/force-download');
			    header("Content-Disposition: attachment; filename=\"" . basename($file) . "\";");
			    header('Content-Transfer-Encoding: binary');
			    header('Expires: 0');
			    header('Cache-Control: must-revalidate');
			    header('Pragma: public');
			    header('Content-Length: ' . filesize($file));
			    ob_clean();
			    flush();
			    readfile("Downloads/".$file); //showing the path to the server where the file is to be download
			    exit;
			}
		}
	}
?>