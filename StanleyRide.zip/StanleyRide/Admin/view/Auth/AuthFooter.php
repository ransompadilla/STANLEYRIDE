
    </div>
<!-- Bootstrap core JavaScript -->
    <script src="Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="Bootstrap/vendor/popper/popper.min.js"></script>
    <script src="Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="Bootstrap/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="Bootstrap/js/jqBootstrapValidation.js"></script>
    <script src="Bootstrap/js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="Bootstrap/js/agency.min.js"></script><!-- Bootstrap core JavaScript -->
    <script src="Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="Bootstrap/vendor/popper/popper.min.js"></script>
    <script src="Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="Bootstrap/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="Bootstrap/js/jqBootstrapValidation.js"></script>
    <script src="Bootstrap/js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="Bootstrap/js/agency.min.js"></script>

  </body>
</html>
