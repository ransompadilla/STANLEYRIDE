<?php
  $flag=0;
    if(isset($_COOKIE['flag'])){
        $flag = $_COOKIE['flag'];
    }
    else $flag=0;
?>
<!DOCTYPE html>
<html>
<head>
  <?php include"model/Bootstrap.php";?>
  <script type="text/javascript">
 
   function validatePassword() {
        var form = document.forms["AuthForm"];
        var password = form["password"].value;
        var c_password = form["c_pass"].value;
        if (c_password != password) {
            document.getElementById('validatePassword').innerHTML = "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>Warning ! Password did not much!</div>";
            return false;
        }
        else{
            password = c_password;
        }

    }
</script>
</head>
<body style="background-image: url('Bootstrap/img/portfolio/05-full.jpg');">
  <form class="login-form" name="AuthForm" method="POST"  onsubmit="return validatePassword();"  enctype="multipart/form-data">  
  <p id="validatePassword"></p>    
        <p>
              <?php 
                if($flag == 1){
                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Added..</div>';
                }
                
              ?>
              
            </p>  
        <div class="row" >
            
            
            
            <div class="col-md-3"></div>
            <div class="col-md-6">
                  <label><h1>Register</h1> </label>
                  <div class="form-group">
                    <input class="form-control" name="name" type="text" placeholder="Your Name *" required data-validation-required-message="Please enter your name here.">
                    <p class="help-block text-danger"></p>
                  </div>
                  
                  <div class="form-group">
                    <input class="form-control" name="address" type="text" placeholder="Your Address *" required data-validation-required-message="Please enter your home address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  
                  <div class="form-group">
                    <input class="form-control" id="fileToUpload" name="fileToUpload" type="file" placeholder="Your Image *" required data-validation-required-message="Please Choose your Image.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="email" type="email" placeholder="Your Email *" required data-validation-required-message="Please enter your email address.">
                    <p class="help-block text-danger"></p>
                  </div>

                  <div class="form-group">
                    <input class="form-control" name="password" type="password" placeholder="Your Password *" required="">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="c_pass" type="password" placeholder="Retype Password *" required="">
                    <p class="help-block text-danger"></p>
                  </div>
                  <button type="submit" name="register_admin" class="btn btn-info" style="width: 49%">
                    Register</button>
                  <a href="index.php" class="btn btn-danger" style="width: 49%">
                    Cancel</a>
                </div>
        </div>
      </form>
</body>
</html>
      