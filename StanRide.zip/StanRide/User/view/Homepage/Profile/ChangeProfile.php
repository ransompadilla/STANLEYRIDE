<form class="login-form" name="AuthForm" method="POST"  onsubmit="return validatePassword();"  enctype="multipart/form-data">  
  <p id="validatePassword"></p>    
        <!-- <p>
              <?php 
                if($flag == 1){
                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Added..</div>';
                }
                
              ?>
              
            </p> -->  
        <div class="row" >
            
            
            
            <div class="col-md-3"></div>
            <div class="col-md-6" style="margin-top: 10%;">
                  <label><h1>Change Profile</h1> </label>
                  <input class="" type="hidden" name="user_id" value="<?php echo $user_id?>"/>
                  <div class="form-group">
                    <input class="form-control" name="user_fname" type="text" value="<?php echo $userInfo['user_fname']?>" required data-validation-required-message="Please enter your name here.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="user_lname" type="text" value="<?php echo $userInfo['user_lname']?>" required data-validation-required-message="Please enter your name here.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="address" type="text" value="<?php echo $userInfo['user_address']?>" required data-validation-required-message="Please enter your home address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <select class="form-control" name="gender">
                      <option value="">Choose Gender</option>
                      <option <?php if($userInfo['user_gender'] == "M")  echo "value='".$userInfo['user_gender']."' Selected";?> >Male</option>
                      <option <?php if($userInfo['user_gender'] == "F")  echo "value='".$userInfo['user_gender']."' Selected";?> >Female</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="bdate" type="text" value="<?php echo $userInfo['user_bdate']?>" required data-validation-required-message="Please enter your home address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="work" type="text" value="<?php echo $userInfo['user_work']?>" required data-validation-required-message="Please enter your home address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="contact" type="text" value="<?php echo $userInfo['user_contact']?>" required data-validation-required-message="Please enter your Contact.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="fileToUpload" name="fileToUpload" type="file" placeholder="Your Image *" required data-validation-required-message="Please Choose your Image.">
                    <p class="help-block text-danger"></p>
                  </div>
                  
                  <button type="submit" name="update_user" class="btn btn-info" style="width: 49%">
                    Update</button>
                  <a href="index.php?homepage=Profile/Profile" class="btn btn-danger" style="width: 49%">
                    Cancel</a>
                </div>
        </div>
      </form>