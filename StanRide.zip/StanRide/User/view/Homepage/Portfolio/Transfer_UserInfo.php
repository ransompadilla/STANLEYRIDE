<?php
	$searchID = $_GET['searched_id'];
	$v_id = $_GET['v_id'];
	$searchUser = $this->model->getUserInformation(array($searchID));
?>
  <p class="text-muted">

                  <?php echo "<strong>Name:</strong> ".$searchUser['user_fname']."&nbsp;".$searchUser['user_lname'];?> <br>
                  <?php echo "<strong>Gender:</strong> ".$searchUser['user_gender'];?> <br>
                  <?php echo "<strong>Job:</strong> ".$searchUser['user_work'];?> <br>
                  <?php echo "<strong>Contact:</strong> ".$searchUser['user_contact'];?> <br>
                  <?php echo "<strong>Address:</strong> ".$searchUser['user_address'];?> <br>
                  <?php echo "<strong>Email:</strong> ".$searchUser['user_email'];?> <br>
                  
              </p>

              <form method="POST" name="form_transfer" onsubmit="return transferPrompt();">
              	<input type="hidden" name="to_user_id" value="<?php echo $searchID?>"/>
              	<input type="hidden" name="from_user_id" value="<?php echo $user_id?>"/>
              	<input type="hidden" name="v_id" value="<?php echo $v_id?>"/>
              	
              <button type="submit" name="submit_transfer">Transfer</button>
              </form>