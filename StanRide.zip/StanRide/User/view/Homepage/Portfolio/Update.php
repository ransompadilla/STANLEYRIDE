<?php
        $v_id = $_GET['v_id'];
       $v = $this->model->GetVehicleByID(array($v_id));
?>
            <section>
              <form class="login-form" name="AuthForm" method="POST"  onsubmit="return validatePassword();"  enctype="multipart/form-data">  
  <p id="validatePassword"></p>    
<div class="container">
        <div class="row" >
            
            
             <p>
              <?php if($flag == "ok"){
                echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Added..</div>';
              }
            
              ?>
              
            </p> 
            <div class="col-md-6" >
              <img src="<?php echo $v['v_img']?>" width="513"><br><br>
              <img src="<?php echo $v['v_cert_reg']?>" width="250">&nbsp;&nbsp;
              <img src="<?php echo $v['v_or']?>" width="250"><br><br>
            </div>
            <div class="col-md-6">
               <label style="color: #ffffff;"><h1>Update Vehicle</h1> </label><br>
                  <input type="hidden" name="user_id" value="<?php echo $user_id?>" />
                  <input type="hidden" name="v_id" value="<?php echo $v_id?>" />
                  
                                           <div class="form-group">
                                            
                                            <div class="col-lg-12">
                                              <select class="form-control" name="service-type" required="">
                                                <option value="">Choose Service Type</option>
                                                <?php
                                                  if($serv_type > 0){
                                                    foreach ($serv_type as $key => $value) {
                                                      if($value['v_service_type_id'] == $v['v_service_type_id']){
                                                        echo "<option value='".$value['v_service_type_id']."' selected>".$value['v_service_desc']."</option>";
                                                      }
                                                      else{
                                                        echo "<option value='".$value['v_service_type_id']."' >".$value['v_service_desc']."</option>";
                                                      }
                                                    }
                                                  }
                                                ?>
                                              </select>
                                            </div>
                                          </div>   
                                          <div class="form-group">
                                            
                                            <div class="col-lg-12">
                                              <input type="text" name="model" value="<?php echo $v['v_model'] ?>" class="form-control" value="" placeholder="Model" required="">
                                            </div>
                                          </div> 
                                          <!-- Content -->
                                          <div class="form-group">
                                            <div class="col-lg-12">
                                              <select class="form-control"  name="brand" required="">
                                                <option value="">Choose Brand</option>
                                                <?php
                                                  if($v_brand > 0){
                                                    foreach ($v_brand as $key => $value) {
                                                      if($value['brand_id']==$v['v_brand_id']){
                                                        echo "<option value='".$value['brand_id']."' selected>".$value['brand_desc']."</option>";
                                                      }
                                                      else{
                                                        echo "<option value='".$value['brand_id']."'>".$value['brand_desc']."</option>";
                                                      }
                                                    }
                                                  }
                                                ?>
                                              </select>
                                            </div>
                                          </div>    
                                          <!-- <div class="form-group">
                                            <label style="color: #ffffff;" class="control-label col-lg-4" for="tags">Vehicle CR</label>
                                            <div class="col-lg-12">
                                              <input type="file" name="v_cert_reg" class="form-control" id="tags" required="">
                                            </div>
                                          </div>   -->               
                                         <!-- <div class="form-group">
                                            <label style="color: #ffffff;" class="control-label col-lg-4" for="tags">Vehicle OR</label>
                                            <div class="col-lg-12">
                                              <input type="file" name="v_or" class="form-control" id="tags" required="">
                                            </div>
                                          </div>  -->
                                          <div class="form-group">
                                            <label style="color: #ffffff;" class="control-label col-lg-4" for="tags">Purchase Date: </label>
                                            <div class="col-lg-12">
                                              <input type="date" value="<?php echo $v['v_purchase_date']?>" name="purchase_date" value="" class="form-control" id="tags" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            
                                            <div class="col-lg-12">
                                              <select class="form-control"  name="color" required="">
                                                <option value="">Choose Color</option>
                                                <option <?php if($v['v_color'] == "Blue") echo 'value="Blue" selected'?> >Blue</option>
                                                <option <?php if($v['v_color'] == "Red") echo 'value="Red" selected'?> >Red</option>
                                                <option <?php if($v['v_color'] == "Green") echo 'value="Green" selected'?> >Green</option>
                                                <option <?php if($v['v_color'] == "Black") echo 'value="Black" selected'?> >Black</option>
                                                <option <?php if($v['v_color'] == "White") echo 'value="White" selected'?> >White</option>
                                              </select>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            
                                            <div class="col-lg-12">
                                              <select class="form-control" name="owner-type" required="">
                                                <option value="">Choose Owner Type</option><option <?php if($v['v_owner_type'] == "1") echo 'value="1" selected'?> >1st</option><option <?php if($v['v_owner_type'] == "2") echo 'value="2" selected'?>>2nd</option><option <?php if($v['v_owner_type'] == "3") echo 'value="3" selected'?>>3rd</option><option <?php if($v['v_owner_type'] == "4") echo 'value="4" selected'?>>4th</option><option <?php if($v['v_owner_type'] == "5") echo 'value="5" selected'?>>5th</option>
                                                
                                              </select>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            
                                            <div class="col-lg-12">
                                              <input type="text" value="<?php echo $v['v_type'];?>" name="v_type" class="form-control" placeholder="Vehicle Type" required="">
                                            </div>
                                          </div>

                                          <!-- <div class="form-group">
                                            <label style="color: #ffffff;" class="control-label col-lg-4" for="tags">Vehicle Image</label>
                                            <div class="col-lg-12">
                                              <input type="file" name="v_img" class="form-control" id="tags" required="">
                                            </div>
                                          </div>  -->
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
                                         <div class="col-lg-offset-2 col-lg-9">
                                          <button type="submit" class="btn btn-success" name="update_vehicle">Submit</button>
                                          <a href="#" class="btn btn-danger">Cancel</a>
                                         </div>
                                          </div>
        </div>
      </form>

          </section>
</div>