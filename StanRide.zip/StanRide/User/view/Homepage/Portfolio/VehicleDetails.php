<?php
  if(isset($_GET['v_id'])){
    $v_detail = $this->model->GetMyVehicleDetails(array($_GET['v_id']));

    $v_id = $v_detail['v_id'];
    // $v_service_type_id = $v_detail['v_service_type_id'];
    // $model = $v_detail['v_model'];
    // $brand_desc = $v_detail['brand_desc'];
    // $v_purchase_date = $v_detail['v_purchase_date'];
    // $v_color = $v_detail['v_color'];
    // $v_owner_type = $v_detail['v_owner_type'];
    // $v_type = $v_detail['v_type'];

    // $v_cr = $v_detail['v_cert_reg'];
    // $v_or = $v_detail['v_or'];
  }
?>
<div style="margin-bottom: 8%">
  
</div>
      
      
    <!-- Team -->
    <section class="bg-light" id="team">
        
     <!--  <p>
              <?php if(isset($_COOKIE['update'])){
                echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Updated...</div>';
              }
            
              ?>
              
            </p>  -->
      <div class="container">
       
        <div class="row">
          <div class="col-sm-6">

            <div class="team-member">
              <img class="mx-auto rounded-circle" src="<?php echo $v_detail['v_img'];?>" alt="">
              <h4><?php echo $v_detail['v_type'];?></h4><br>
              <a class="btn btn-success" href="index.php?homepage=Portfolio/Transfer&v_id=<?php echo $v_id ?>">TRANSFER MY CAR </a>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="">
              
              <p class="text-muted">
                  <?php echo "<strong>Service Type:</strong> ".$v_detail['v_service_desc'];?> <br>
                  <?php echo "<strong>Model:</strong> ".$v_detail['v_model'];?> <br>
                  <?php echo "<strong>Brand:</strong> ".$v_detail['brand_desc'];?> <br>
                 
                  <?php echo "<strong>Purchase Date:</strong> ".$v_detail['v_purchase_date'];?> <br>
                  <?php echo "<strong>Color:</strong> ".$v_detail['v_color'];?> <br>
                  <?php echo "<strong>Owner Type:</strong> ".$v_detail['v_owner_type'];?> <br>
                  <?php echo "<strong>Vehicle Type: </strong> ".$v_detail['v_type'];?> <br>
                  
              </p>
              <a class="btn btn-primary" data-toggle="modal" href="#view-cr">View CR</a> | <a class="btn btn-primary" data-toggle="modal" href="#view-or">View OR</a><br><br>
              <ul class="list-inline social-buttons">
                <li class="list-inline-item">
                  <a class="btn btn-danger" href='index.php?homepage=Portfolio/Update&v_id=<?php echo $v_id;?>'>
                    <i class="fa fa-edit"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-danger" href="#">
                    <i class="fa fa-lock"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a class="btn btn-danger" href="#">
                    <i class="fa fa-remove"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
    
        </div>
        <hr>
        <div class="row" style="margin-left: 10%;">
          <?php
            foreach ($v_parts as $k => $v) {
              echo '
                <div class="col-sm-3">
                  <a data-toggle="modal" href="#vpart'.$v['v_part_id'].'vid'.$v_id.'">
                  <img src="'.$v['v_part_icon'].'" width="100"><br></a>';
                  
                  $vChange = $this->model->GetPartChangeLastDate(array($v_id, $v['v_part_id']));

                  $lastDate = $this->model->GetPartChangeGetLastDate(array($v_id, $v['v_part_id']));
                  $vpartD = $this->model->GetPartChangeDetails($v_id, $v['v_part_id']);
                  if(count($vpartD) > 0){
                  $d = strtotime($lastDate['change_date']);
                  $date1 = Date("m/j/Y",$d);
                  echo "Last Date: ".$date1."<br>";
                  echo "No. Of Update: ".count($vpartD)."<br>";
                  }
                  else{
                    echo "No. Of Update: 0<br>";
                  }


                    if($vChange['pending'] == 1){
                      $std = strtotime($vChange['change_date']);
                      $date11 = Date("m/j/Y",$std);
                      
                      if($std1 >= $std){
                        $this->model->UpdateNotifVpartChange(array(1, $v_id, $v['v_part_id']));
                        echo '
                          <form method="POST">
                            <input type="hidden" name="v_id" value="'.$v_id.'">
                            <input type="hidden" name="v_part_id" value="'.$v['v_part_id'].'">
                            <button type="submit" name="acknowledge" class="btn btn-primary">Acknowledge</button>
                          </form>
                        ';
                      }
                      else{
                        echo "Pending: true <br>";
                        echo "Schedule Updated: ".$date11."<br>";
                      }
                    }
                    else{
                      echo "Pending: NO";
                    } 
                  
                echo '</div>
              ';
            }
          ?>
            <!-- 
            <div class="col-sm-3">
              <img src="../Bootstrap/img/portfolio/wheel-icon.jpg" width="70"><br>
              Wheel
            </div>
            <div class="col-sm-3">
              <img src="../Bootstrap/img/portfolio/engine-icon.png" width="100"><br>
              ENGINE
            </div>
            <div class="col-col-sm-3">
              <img src="../Bootstrap/img/portfolio/engine-icon.png" width="100"><br>
              ENGINE
            </div>
            
 -->
        </div>
      </div>
    </section>
    <!-- MODAL -->
    <?php
      for($i=0;$i<=10;$i++){

        $vpartChange = $this->model->GetPartChangeLastDate(array($v_id, $i));
        $vpartDetails = $this->model->GetPartChangeDetails($v_id, $i);
        $lastDate = $this->model->GetPartChangeGetLastDate(array($v_id, $i));
        $vpartid =  $this->model->GetVehiclePartByID(array($i));
        $d = strtotime($lastDate['change_date']);
        $date1 = Date("m/j/Y",$d);
        echo '
          <div class="portfolio-modal modal fade" id="vpart'.$i.'vid'.$v_id.'" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                  <div class="lr">
                    <div class="rl"></div>
                  </div>
                </div>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-8 mx-auto">
                      <div class="modal-body">
                        <!-- Project Details Go Here -->
                        <h2>'.$vpartid['v_part_desc'].'</h2>
                        <!-- <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p> -->
                        <img class="img-fluid d-block mx-auto" src="'.$vpartid['v_part_icon'].'" alt="">
                        Service Type: '.$vpartChange['v_service_desc'].'<br>
                        Description: '.$vpartChange['description'].'<br>
                        Last Date Change: '.$date1.'<br>
                        No. Of Change: '.count($vpartDetails).' <br>';
                        if($vpartChange['pending'] == 1){
                          echo "Pending: true";
                          echo "<br>Schedule Updated: ".$vpartChange['change_date']."<br>";
                        }
                        else{
                          echo "<br>";
                        }
                        
                        echo'<a data-toggle="modal" href="#update_vpart'.$i.'details'.$v_id.'" class="btn btn-danger">Update </a> | 
                        <a data-toggle="modal" href="#vpart'.$i.'details'.$v_id.'" class="btn btn-danger">Details </a> <br><br>
                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          ';
          
          echo '
          <div class="modal fade" id="vpart'.$i.'details'.$v_id.'" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                  <div class="lr">
                    <div class="rl"></div>
                  </div>
                </div>
                      <div class="modal-body">
                        <!-- Project Details Go Here -->
                        <table class="table table-stripped">
                        ';
                        if(count($vpartDetails) > 0){
                          echo '<th>Service Type</th><th>Description</th><th>Date Updated</th>';
                          foreach ($vpartDetails as $k2 => $v2) {
                            echo '    
                                  <tr>
                                    <td>'.$v2['v_service_desc'].'</td>
                                    <td>'.$v2['description'].'</td>
                                    <td>'.$v2['change_date'].'</td>
                                  </tr>';
                                
                          }
                        }else{echo '<strong>No Record...</strong>';}
                        echo '
                        </table>
                        <button class="btn btn-primary" data-dismiss="modal" type="button" style="width: 100%;">
                    <i class="fa fa-times"></i>
                    Close </button>
                      </div>
                    </div>
            </div>
          </div>

        ';
       
       echo '
          <div class="modal fade" id="update_vpart'.$i.'details'.$v_id.'" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                  <div class="lr">
                    <div class="rl"></div>
                  </div>
                </div>
                <div class="container">
                  <div class="row">
                    <div class="col-lg-8 mx-auto">
                      <div class="modal-body">
                        <!-- Project Details Go Here -->

                        <form method="POST">
                        <input type="hidden" name="user_id" value="'.$user_id.'"/>
                        <input type="hidden" name="v_part_id" value="'.$i.'"/>
                        <input type="hidden" name="v_id" value="'.$v_id.'"/>
                        <select class="form-control" name="uservice-type" required="">
                          <option value="">Choose Service Type</option>
                          ';
                          
                              if($serv_type > 0){
                                foreach ($serv_type as $k2 => $v3) {
                                  echo "<option value='".$v3['v_service_type_id']."'>".$v3['v_service_desc']."</option>";
                                }
                             }
                                                
                        echo '</select><br>
                        <textarea class="form-control" name="description" placeholder="Description..."></textarea><br>
                        Schedule Date: <br>
                        <input type="date" class="form-control" name="udate" required/><br>
                        <button class="btn btn-success"  type="submit" name="update_vpart_date" style="width: 49%;">
                    UPDATE </button>
                        <button class="btn btn-primary" data-dismiss="modal" type="button" style="width: 49%;">
                    <i class="fa fa-times"></i>
                    Cancel </button>
                    </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        ';
      }
    ?>
    
    <!-- MODAL -->
    <div class="portfolio-modal modal fade" id="view-cr" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2>Vehicle Certificate of Registration</h2>
                  <!-- <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p> -->
                  <img class="img-fluid d-block mx-auto" src="<?php echo $v_detail['v_cert_reg']?>" alt="">
                
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="portfolio-modal modal fade" id="view-or" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2>Vehicle Official Receipt</h2>
                  <!-- <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p> -->
                  <img class="img-fluid d-block mx-auto" src="<?php echo $v_detail['v_or']?>" alt="">
                  
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
