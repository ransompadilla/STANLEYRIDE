<?php
  $v_id = $_GET['v_id'];
  $v_detail = $this->model->GetVehicleByID(array($v_id));
?>
<div style="margin-bottom: 8%">
</div>
      
      
    <!-- Team -->
    <section class="bg-light" id="team">
        
         <!--  <?php
        if($update == "ok"){
                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Updated..</div>';
                }
      ?> -->
      
      <div class="container">
       
        <div class="row">
          <div class="col-sm-6">

            <div class="team-member">
              <img class="img-fluid d-block mx-auto" src="<?php echo $v_detail['v_img']?>" alt="">
              <h4><?php echo $v_detail['v_type']."<br>".$v_detail['v_model'];?></h4>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="">
              <select class="form-control" id="users">
                <option value="">Transfer TO</option>
                <?php
                  $users = $this->model->GetAllUser($user_id);
                  foreach ($users as $key => $value) {
                    # code...
                  
                  echo "<option value='".$value['user_id']."/".$v_detail['v_id']."'>".$value['user_fname']." &nbsp; ".$value['user_lname']."</option>";
                 }
                ?>
              </select>
              <p id="loading-page"></p>
              <br>
              
            </div>
          </div>
    
        </div>
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <p class="large text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Clients -->