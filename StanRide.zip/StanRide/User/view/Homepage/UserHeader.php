<?php 
    if(isset($_COOKIE['update'])){
          $update=$_COOKIE['update'];
    }
    else $update = null;
    
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "model/Bootstrap.php"; ?>
  <script src="../Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="../Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript">
  
  $(document).ready(function(){
    //alert("asdf");
    $('.appendhere').hide();
    $('.appendInput').change(function(){
      var value = $(this).val();
      if(value==2){
      $('.appendhere').show();
      }
      else if(value==1){
      $('.appendhere').hide();
      }
    });
    $('#users').change(function(){
      var user_id = $('#users').val();
      var res = user_id.split("/");
        if (window.XMLHttpRequest){
            xmlhttp=new XMLHttpRequest();
        }
        else{
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
       var PageToSendTo = "index.php?homepage=Portfolio/Transfer_UserInfo.php?searched_id="+res[0]+"&v_id="+res[1];
          xmlhttp.open("GET", PageToSendTo, false);
          xmlhttp.send();
           $("#loading-page").load("index.php?homepage=Portfolio/Transfer_UserInfo&searched_id="+res[0]+"&v_id="+res[1]+"", function(responseTxt, statusTxt, xhr){
        });
        
    });
    
   });

  function transferPrompt(){
    var form = document.forms['form_transfer'];
      var v_id = form['v_id'].value;
      var to_user_id = form['to_user_id'].value;
      var from_user_id = form['from_user_id'].value;

      var conf = confirm("If you agree this transaction you will no longer acces with this vehicle...");
      if(conf==true){
        if (window.XMLHttpRequest){
            xmlhttp=new XMLHttpRequest();
        }

        else{
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
       var PageToSendTo = "index.php?submit_transfer=1&v_id="+v_id+"&to_user_id="+to_user_id+"&from_user_id="+from_user_id;
          xmlhttp.open("POST", PageToSendTo, false);
          xmlhttp.send();

          alert("Transaction Success...");
      }
      else{return false;}
      
      
  }
  
  </script>
  <style type="text/css">
      #notif:hover{background-color: #d0d0d0;}
      #notif a {color: #000000; text-decoration: none;}
      #notif{padding:5px;}

      .user-details {position: relative; padding: 0;}
      .user-details .user-image {position: relative;  z-index: 1; width: 100%; text-align: center;}
       .user-image img { clear: both; margin: auto; position: relative;}
       .user-info-block{margin-top: 70px}
      .user-details .user-info-block {width: 100%; position: absolute; top: 55px; background: rgb(255, 255, 255); z-index: 0; padding-top: 35px;}
       .user-info-block .user-heading {width: 100%; text-align: center; margin: 10px 0 0;}
       .user-info-block .navigation {float: left; width: 100%; margin: 0; padding: 0; list-style: none; border-bottom: 1px solid #428BCA; border-top: 1px solid #428BCA;}
        .navigation li {float: left; margin: 0; padding: 0;}
         .navigation li a {padding: 20px 30px; float: left;}
         .navigation li.active a {background: #428BCA; color: #fff;}
       .user-info-block .user-body {float: left; padding: 5%; width: 90%;}
        .user-body .tab-content > div {float: left; width: 100%;}
        .user-body .tab-content h4 {width: 100%; margin: 10px 0; color: #333;}

       

    </style>
</head>
<body id="page-top" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Stanley Ride</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Portfolio/Portfolio">Portfolio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=RegisterVehicle">Register Vehicle</a>
            </li>
            <li class="nav-item">
            <div class="dropdown">
            
            <?php $count = count($this->model->CountNotif($user_id));?>
              <a class="nav-link js-scroll-trigger dropdown-toggle" data-toggle="dropdown" href="#"><span class="fa fa-globe"><i class="badge"><?=$count;?></i></span>
              </a>
              <ul class="dropdown-menu" style="padding: 10px; width: 300px; margin-left: -20px;  overflow: auto; height: 500px;">
              <?php
                foreach ($notifPart as $np) {
                  $std = strtotime($np['change_date']);
                  $date1 = Date("m/j/Y",$std);
                  if($std1 == $std){
                    echo '<li style="background-color:#e0e0e0;" id="notif"><a href="#">
                      <p class="pull-right"><br>REMINDER: <i class="small text-muted" style="margin-left:10px;">Please go to '.$np['v_service_desc'].' and check your Vehicle '.$np['v_part_desc'].'<img src="'.$np['v_part_icon'].'" width="30" /> for this is the appointed time , THANKS :) '.$date1.'</i> 
                        
                        </a></li><hr>';
                  }
                  else if($std1 >= $std){
                    echo '<li style="background-color:#e0e0e0;" id="notif"><a href="#">
                      <p class="pull-right"><br>REMINDER: <i class="small text-muted" style="margin-left:10px;">Please go to '.$np['v_service_desc'].' and check your Vehicle '.$np['v_part_desc'].'<img src="'.$np['v_part_icon'].'" width="30" /> for the appointed time has come , THANKS :) '.$date1.'</i> 
                        
                        </a></li><hr>';
                  }
                }
              ?>
              </ul>
            </div>
            </li>
            <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="index.php?homepage=Profile/Profile">
              <img class="img-circle" src="<?=$img;?>" width="20">
              <?=$name;?>
            </a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?logout=1">logout</a>
            </li>
          </ul>
        </div>
      </div>

    </nav>
    

