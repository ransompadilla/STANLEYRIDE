<?php
	include_once("model/Model.php");
	class Controller{
		public	$model;
		public	function __construct(){		
			$this->model = new Model();
		}
		public function invoke(){
			 $this->Delete();
			 $this->Update();
			//  //$this->Retrieve();
			$this->Download();
		    $this->Create();
		    $this->Logout();
		    $this->ValidateLogin();
			 

			
			$this->AUTH();
		}
		
		public function AUTH(){
			if(isset($_GET['auth'])){
				$auth = rtrim($_GET['auth'], '/');
				include 'view/Auth/'.$auth.'.php';
			}
			else if(isset($_GET['homepage'])){
				$this->Retrieve(); 	
			 }
			 else{
			
				include 'view/index.php';
				
			}	
			
		}
		//
		public function ValidateLogin(){
			if(isset($_POST['login_user'])){
				$email = $_POST['email'];
				$password = $_POST['password'];
				$row = $this->model->ValidateUserLogin(array($email,$password));
				if(count($row) > 1){
                setcookie("user_id", $row['user_id'], time() + 86400, "/"); // 86400 = 1 day
                header("Location: index.php?homepage=Home");
            }
            else{
                header('location: index.php?auth=Authentication');
            }
			}
		}
		public function Logout(){
			if(isset($_GET['logout'])){
				$this->model->User_Logout();
			}
		}
		//
		public function Create(){
			
			//REGISTER User
			if(isset($_POST['register_user'])){
				
				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$bdate = $_POST['bdate'];
				$work = $_POST['work'];
				$contact = $_POST['contact'];
				$email = $_POST['email'];
				$password = $_POST['pword'];

				if($this->model->CheckEmail(array($email)) == NULL){
					$this->model->RegisterUser(array($fname,$lname,$gender,$address,$bdate, $work, $contact, $email, $password, 0));
			        setcookie("flag", "ok", time() + 3, "/");
				}
				else{
					setcookie("flag", "used", time() + 3, "/");
				}
					header("Location: index.php?auth=Register");
			}
			//REGISTER VEHICLE
			if(isset($_POST['register_vehicle'])){
				$user_id = $_POST['user_id'];
				$serv_type = $_POST['service-type'];
				$v_model = $_POST['model'];
				$v_brand = $_POST['brand'];
				//$v_cert_reg = $_POST['v_cert_reg'];
				//$v_or = $_POST['v_or'];
				$purchase_date = $_POST['purchase_date'];

				$v_color = $_POST['color'];
				$owner_type = $_POST['owner-type'];
				$v_type = $_POST['v_type'];

				$target_dir = "../Bootstrap/img/";
				$v_cert_reg = $target_dir . basename($_FILES["v_cert_reg"]["name"]);
				$v_or = $target_dir . basename($_FILES["v_or"]["name"]);
				$v_img = $target_dir . basename($_FILES["v_img"]["name"]);
				 if (move_uploaded_file($_FILES["v_cert_reg"]["tmp_name"], $v_cert_reg)) {
				        echo "The file ". basename( $_FILES["v_cert_reg"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				   if (move_uploaded_file($_FILES["v_or"]["tmp_name"], $v_or)) {
				        echo "The file ". basename( $_FILES["v_or"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				    if (move_uploaded_file($_FILES["v_img"]["tmp_name"], $v_img)) {
				        echo "The file ". basename( $_FILES["v_img"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
			    $data = array($user_id,$serv_type,$v_model,$v_brand,$v_cert_reg,$v_or,$purchase_date,$v_color,$owner_type,$v_type,$v_img,0,0);
		        setcookie("flag", "ok", time() + 5, "/");
				$this->model->RegisterVehicle($data);
				header('Location:index.php?homepage=RegisterVehicle');
			}
			//Change v part
			if(isset($_POST['update_vpart_date'])){
				$v_id = $_POST['v_id'];
				$vpart_id = $_POST['v_part_id'];
				$user_id = $_POST['user_id'];
				$desc = $_POST['description'];
				$udate = $_POST['udate'];
				$v_serv_type_id = $_POST['uservice-type'];

				$this->model->UpdateVpart(array($desc, $udate, $v_serv_type_id, 1,0,1, $vpart_id, $v_id, $user_id));
				header('Location:index.php?homepage=Portfolio/VehicleDetails&v_id='.$v_id.'');
			}
		}
		public function Retrieve(){
				if(isset($_COOKIE['user_id'])){
				date_default_timezone_set('Asia/Manila');
				$date = Date("m/j/Y");
				 $std1 = strtotime($date);
    //               $date1 = Date("F j, Y",$d);

    //               $date2 = Date("y-m-d",$d);
			        $user_id=$_COOKIE['user_id'];
			         $name = $this->model->getUserNameByID(array($user_id));
			         $img = $this->model->getUserImgByID(array($user_id));
			         $userInfo = $this->model->getUserInformation(array($user_id));
			         $v_brand = $this->model->GetVehicleBrand();
			         $serv_type = $this->model->GetServiceType();     
			         $v_details = $this->model->GetMyVehicle($user_id);
			         $v_parts = $this->model->GetVehicleParts();
			         $vpartMax = $this->model->GetMaxVPartID();
			         $vMax = $this->model->GetMaxVID();
			         $notifPart = $this->model->GetVPartChangeWithNotif();
			         foreach ($vpartMax as $k => $v) {$VPartMaxID = $v['vpartMax'];}
			         foreach ($vMax as $k => $v) {$VMaxID = $v['vMax'];}
			         $flag="";
			         if(isset($_COOKIE['flag'])){
			         	$flag = $_COOKIE['flag'];
			         }
			        if(isset($_GET['homepage'])){
			        	
			        	$homepage = null;
							$flag = rtrim($_GET['homepage'], '/');
							$page = array("Home","Profile/Profile", "Profile/ChangeProfile", "Profile/ChangePassword","RegisterVehicle", "Portfolio/Portfolio", "Portfolio/VehicleDetails", "Portfolio/Update","Portfolio/Transfer","Portfolio/Transfer_UserInfo", "Transaction", "Post");
							for($i=0;$i<count($page);$i++){
								if($flag == $page[$i]){
									$homepage = $flag;
									if($homepage == $page[9]){
										include 'view/Homepage/'.$homepage.'.php';
									}
									else{
										include 'view/Homepage/UserHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/UserFooter.php';
									}
										
									
								}
								else $homepage = $homepage;
						}
					 		
			 		
						 		
					}
					
				}
		    else{
		      header('location: index.php');
		    }				

		}
		public function Update(){
			//
			if(isset($_POST['update_user'])){
				$user_id = $_POST['user_id'];
				$user_fname = $_POST['user_fname'];
				$user_lname = $_POST['user_lname'];
				$address = $_POST['address'];
				$gender = $_POST['gender'];
				$bdate = $_POST['bdate'];
				$work = $_POST['work'];
				$contact = $_POST['contact'];

				$folder = "../Bootstrap/file/";
				$temp = explode(".", $_FILES["uploaded"]["name"]);
				$newfilename = round(microtime(true)).'.'. end($temp);
				$db_path ="$folder".$newfilename  ;
				$listtype = array(
				'.doc'=>'application/msword',
				'.docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'.rtf'=>'application/rtf',
				'.pdf'=>'application/pdf'); 
				if ( is_uploaded_file( $_FILES['uploaded']['tmp_name'] ) ){
					if($key = array_search($_FILES['uploaded']['type'],$listtype)){
						if (move_uploaded_file($_FILES['uploaded']  ['tmp_name'],"$folder".$newfilename)){
						echo "The file ". basename( $_FILES["uploaded"]["name"]). " has been uploaded.";
						}
					}
					else {
					echo "File Type Should Be .Docx or .Pdf or .Rtf Or .Doc";
					}
				}
				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->UpdateUserInfo(array($user_fname,$user_lname, $address, $gender, $bdate, $work,$contact, $target_file, $user_id));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?homepage=Profile/Profile");
			}
			//Change Email
			if(isset($_POST['change_user_email'])){
		    $user_id = $_POST['user_id'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			$c_password = $_POST['current_password'];
		    $data = array($email,$user_id);
		    $check_email = $this->model->CheckUserEmail(array($email));
		    $check_pass = $this->model->CheckUserPassword(array($c_password, $user_id));
	        //setcookie("emp_email", $email, time() + 86400, "/");
	        if($check_email == NULL && $check_pass == "Checked"){
				$this->model->ChangeUserEmail($data);
				setcookie("update", "ok", time() + 5, "/");
		        setcookie("emp_email", $email, time() + 86400, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
			else{
				setcookie("update", "used", time() + 5, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
		}
		//ChangePassword
		if(isset($_POST['change_user_password'])){
		    $user_id = $_POST['user_id'];
			$password = $_POST['password'];
			$c_password = $_POST['current_password'];
		    $found = $this->model->CheckUserPassword(array($c_password, $user_id));
			if($found){
				$data = array($password,$user_id);
	        	$this->model->ChangeUserPassword($data);
				setcookie("update", "ok", time() + 5, "/");
				header('Location: index.php?homepage=Profile/Profile');
			
			}
			else {

				setcookie("update", "notok", time() + 5, "/");
				header('Location: index.php?homepage=Profile/ChangePassword');
			}
		    
		}
		//update vpart
		if(isset($_POST['update_vehicle'])){
			$user_id = $_POST['user_id'];
			$v_id = $_POST['v_id'];
			$serv_type = $_POST['service-type'];
			$v_model = $_POST['model'];
			$v_brand = $_POST['brand'];
				//$v_cert_reg = $_POST['v_cert_reg'];
				//$v_or = $_POST['v_or'];
			$purchase_date = $_POST['purchase_date'];

			$v_color = $_POST['color'];
			$owner_type = $_POST['owner-type'];
			$v_type = $_POST['v_type'];

			$this->model->UpdateVehicle(array($serv_type,$v_model, $v_brand, $purchase_date, $v_color, $owner_type, $v_type,$v_id, $user_id));
			setcookie("update", true, time() + 5, "/");
			header("location: index.php?homepage=Portfolio/VehicleDetails&v_id=".$v_id);
		}
		if(isset($_POST['acknowledge'])){
			$v_part_id = $_POST['v_part_id'];
			$v_id = $_POST['v_id'];
			$this->model->AcknowledgePending(array(0,0,$v_id,$v_part_id));
			header("location: index.php?homepage=Portfolio/VehicleDetails&v_id=".$v_id);
		}
		if(isset($_POST['submit_transfer'])){
			$to_user_id = $_POST['to_user_id'];
			$from_user_id = $_POST['from_user_id'];
			$v_id = $_POST['v_id'];

			$this->model->TransferUpdateVehicle(array($to_user_id, $v_id));
			$this->model->TransferUpdateVPChange(array($to_user_id, $v_id));
			$this->model->RegisterTOTransaction(array($from_user_id, $to_user_id, $v_id));
			header("location: index.php?homepage=Portfolio/Portfolio");
		}
		}
		public function Delete(){
			if(isset($_GET['id'])){
				$id=$_GET['id'];
					$this->model->DeleteApplicant(array($id));
					header('Location: index.php?homepage=Portfolio');	
			}
		}
		public function Download(){
			if(isset($_GET['file'])){
				$file = $_GET['file'];
				header('Content-Description: File Transfer');
			    header('Content-Type: application/force-download');
			    header("Content-Disposition: attachment; filename=\"" . basename($file) . "\";");
			    header('Content-Transfer-Encoding: binary');
			    header('Expires: 0');
			    header('Cache-Control: must-revalidate');
			    header('Pragma: public');
			    header('Content-Length: ' . filesize($file));
			    ob_clean();
			    flush();
			    readfile("Downloads/".$file); //showing the path to the server where the file is to be download
			    exit;
			}
		}
	}
?>