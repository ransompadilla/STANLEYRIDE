<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterUser($data){
            $query = "INSERT INTO user(user_fname,user_lname,user_gender, user_address, user_bdate,user_work, user_contact, user_email, user_password, subscribe) VALUES(?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
        //
        public function RegisterTOTransaction($data){
            $query = "INSERT INTO transactions(v_id, tr_from, tr_to) VALUES(?,?,?);";
            $this->crud->Insert($query,$data);
        }
         public function RegisterVehicle($data){
            $query = "INSERT INTO vehicle(user_id, v_service_type_id, v_model, v_brand_id, v_cert_reg, v_or, v_purchase_date, v_color, v_owner_type, v_type, v_img, v_subscribe,v_notif) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?);";
            $this->crud->Insert($query,$data);
        }
        public function UpdateVpart($data){
            $query = "INSERT INTO vehicle_part_change(description, change_date, v_service_type_id,pending,notif,notif_subs, v_part_id, v_id, user_id) VALUES(?,?,?,?,?,?,?,?,?);";
            $this->crud->Insert($query, $data);
        }
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set cust_email=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        public function CheckUserPassword($data){
            $query = "SELECT user_password FROM user WHERE user_password=? and user_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function ChangeUserPassword($data){
            $query = "UPDATE user set user_password=? where user_id=?";
            $this->crud->Update($query,$data);

        }
        //
        public function GetAllUser($data){
            $query = "SELECT * FROM user WHERE user_id != $data; ";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK EMAIL
        public function CheckEmail($data){
            $check=NULL;
            $query = "SELECT * FROM user where user_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //CHECK PASSWORD
        public function CheckPassword($data){
            $check=NULL;
            $query = "SELECT * FROM user where user_id=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //VALIDATE LOGIN
        public function ValidateUserLogin($data){
            $query = "SELECT * FROM user where user_email=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function User_Logout(){
            if(isset($_COOKIE['user_id'])){
                setcookie("user_id",$_COOKIE['user_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        //get notification
        public function CountNotif($data){
            $query = "SELECT notif FROM vehicle_part_change WHERE notif=1 and user_id = $data";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetVPartChangeWithNotif(){
            $query = "SELECT vpc.*, vst.*, v.*, vp.* FROM vehicle_part_change vpc, service_type vst, vehicle v, vehicle_part vp WHERE vpc.v_id=v.v_id and vpc.v_service_type_id = vst.v_service_type_id and vpc.v_part_id = vp.v_part_id and vpc.notif=1 ORDER BY vpc.change_date DESC;";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        //
        public function GetPartChangeDetails($v_id, $vpart_id){
            $query = "SELECT vpc.*, vst.* FROM vehicle_part_change vpc, service_type vst WHERE vpc.v_id=$v_id and vpc.v_service_type_id = vst.v_service_type_id and vpc.v_part_id = $vpart_id and vpc.pending=0 ORDER BY vpc.change_date DESC;";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetPartChangeLastDate($data){
            $query = "SELECT vpc.*, vst.* FROM vehicle_part_change vpc, service_type vst WHERE vpc.v_id=? and vst.v_service_type_id = vpc.v_service_type_id and vpc.v_part_id = ? ORDER BY vpc.change_date DESC;";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function GetPartChangeGetLastDate($data){
            $query = "SELECT change_date FROM vehicle_part_change WHERE v_id=? and v_part_id = ? and pending=0 ORDER BY change_date DESC;";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        //GETVEHICLEPARTS
        public function GetVehicleParts(){
            $query = "SELECT * FROM vehicle_part";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetVehiclePartByID($data){
            $query = "SELECT * FROM vehicle_part WHERE v_part_id=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function GetVehicleByID($data){
            $query = "SELECT * FROM vehicle WHERE v_id=?";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }

        public function GetMaxVPartID(){
            $query = "SELECT max(v_part_id) as vpartMax FROM vehicle_part";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetMaxVID(){
            $query = "SELECT max(v_id) as vMax FROM vehicle";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        //GETVEHICLEBRAND
        public function GetVehicleBrand(){
            $query = "SELECT * FROM brand";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        //GETSERVICE TYPE
        public function GetServiceType(){
            $query = "SELECT * FROM service_type";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        //GET MY VEHCLE DETAILS
        public function GetMyVehicle($data){
            $query = "SELECT v.*, b.*, s_type.* FROM vehicle v, brand b, service_type s_type WHERE v.user_id=$data and v.v_service_type_id = s_type.v_service_type_id and v.v_brand_id=b.brand_id";
            
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function GetMyVehicleDetails($data){
            $query = "SELECT v.*, b.*, s_type.* FROM vehicle v, brand b, service_type s_type WHERE v.v_id=? and v.v_service_type_id = s_type.v_service_type_id and v.v_brand_id=b.brand_id";
            
            $rows = $this->crud->Select($query, $data);
            return $rows;
        }
        public function getUserInformation($data){
             
            $query = "SELECT * FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            
            return $row;
        }
        public function getUserNameByID($data){
            $name=null;
            $query = "SELECT user_fname, user_lname FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['user_fname']." ".$row['user_lname'];
            }
            return $name;
        }
        public function getUserImgByID($data){
            $img=null;
            $query = "SELECT user_img FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['user_img'];
            }
            else $img=null;
            return $img;
        }
        //AMDIN SIDE
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_name FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_name'];
            }
            return $name;
        }
        public function getAdminImgByID($data){
            $img=null;
            $query = "SELECT admin_img FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['admin_img'];
            }
            else $img=null;
            return $img;
        }
        
        //UPDATE
        public function UpdateUserInfo($data){
            $query = "UPDATE user SET user_fname=?,user_lname=?, user_address=?, user_gender=?, user_bdate=?, user_work=?, user_contact=?, user_img=? WHERE user_id=?";
            $this->crud->Update($query, $data);
        }
        //
        public function UpdateVehicle($data){
            $query = "UPDATE vehicle SET v_service_type_id=?, v_model=?, v_brand_id=?, v_purchase_date=?, v_color=?, v_owner_type=?, v_type=? WHERE v_id=? and user_id=?";
            $this->crud->Update($query, $data);
        }
        //UPDATE NOTIF VPARTCHANGE
        public function UpdateNotifVpartChange($data){
            $query = "UPDATE vehicle_part_change SET notif=? WHERE v_id=? and v_part_id=?";
            $this->crud->Update($query, $data);
        }
        public function AcknowledgePending($data){
            $query = "UPDATE vehicle_part_change SET pending=? , notif=? WHERE v_id=? and v_part_id=?";
            $this->crud->Update($query, $data);
        }
        //TRANSFER VEHICLE
        public function TransferUpdateVPChange($data){
            $query = "UPDATE vehicle_part_change SET user_id=? WHERE v_id=?";
            $this->crud->Update($query, $data);
        }
        public function TransferUpdateVehicle($data){
            $query = "UPDATE vehicle SET user_id=?, v_owner_type = (v_owner_type + 1) WHERE v_id=?";
            $this->crud->Update($query, $data);

        }

	}
?>