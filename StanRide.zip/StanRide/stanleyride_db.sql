-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2017 at 01:31 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tanagency_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(25) DEFAULT NULL,
  `admin_address` varchar(50) DEFAULT NULL,
  `admin_email` varchar(50) DEFAULT NULL,
  `admin_password` varchar(50) DEFAULT NULL,
  `admin_img` blob,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9000004 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_address`, `admin_email`, `admin_password`, `admin_img`) VALUES
(3, 'Ghe Mariefe', 'Biasong, Talisay City, Cebu', 'ghe@yahoo.com', 'ghe', 0x2e2e2f426f6f7473747261702f696d672f31313231393038335f3932383332363837373230363831335f383838313330383032393032353533313930385f6e2e6a7067),
(4, 'Jhudey', 'Biasong, Talisay City, Cebu', 'jhudey@yahoo.com', 'jhudey', 0x2e2e2f426f6f7473747261702f696d672f31343635303139375f3331333530303434323337353836325f353837333732393634303330343330303037385f6e2e6a7067),
(9000001, 'Alejandro', 'Mambaling', 'alejandro@yahoo.com', 'alejandro', 0x2e2e2f426f6f7473747261702f696d672f6176617461722d6d696e69322e6a7067),
(9000002, 'Ransom', 'Carino', 'ransom@yahoo.com', 'ransom', 0x2e2e2f426f6f7473747261702f696d672f3535393534365f3737373635393039323237333539335f323831353431353838383138323236313033305f6e2e6a7067),
(9000003, 'lem', 'cebu city', 'melle@yahoo.com', '12345', 0x2e2e2f426f6f7473747261702f696d672f6176617461722d6d696e69322e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `applicant_info`
--

CREATE TABLE IF NOT EXISTS `applicant_info` (
  `app_id` int(11) NOT NULL AUTO_INCREMENT,
  `app_lname` varchar(25) DEFAULT NULL,
  `app_fname` varchar(25) DEFAULT NULL,
  `app_age` varchar(3) DEFAULT NULL,
  `app_gender` char(1) DEFAULT NULL,
  `app_address` varchar(100) DEFAULT NULL,
  `app_contact` varchar(15) DEFAULT NULL,
  `app_img` blob,
  `app_resume` blob,
  `date_register` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `app_status` int(1) DEFAULT NULL,
  `active` int(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `approve` int(1) DEFAULT NULL,
  PRIMARY KEY (`app_id`),
  KEY `cons_user_id_app` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `applicant_info`
--

INSERT INTO `applicant_info` (`app_id`, `app_lname`, `app_fname`, `app_age`, `app_gender`, `app_address`, `app_contact`, `app_img`, `app_resume`, `date_register`, `app_status`, `active`, `user_id`, `approve`) VALUES
(24, 'Baylon', 'Danly', '22', 'M', 'Pardo, Talisay City, Cebu', '09234815395', 0x2e2e2f426f6f7473747261702f696d672f31353431393738385f3335353337383136313532313432335f3931383833303738393436303331353138355f6f2e6a7067, 0x2e2e2f426f6f7473747261702f66696c652f313530383632353637352e646f6378, '2017-10-21 22:41:14', 0, 1, 1004, 1),
(25, 'Bonje', 'Ronald', '22', 'M', 'Lahug', '09234815395', 0x2e2e2f426f6f7473747261702f696d672f696d67322e6a7067, 0x2e2e2f426f6f7473747261702f66696c652f313530383632383235302e646f6378, '2017-10-21 23:24:10', 1, 1, 1002, 1);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `tr_id` int(11) DEFAULT NULL,
  `sender` int(11) DEFAULT NULL,
  `messages` varchar(500) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `con_tr_id` (`tr_id`),
  KEY `con_user_idd` (`sender`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `tr_id`, `sender`, `messages`, `date`, `status`) VALUES
(34, 17, 9000002, 'okey', '2017-10-21 23:09:10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `app_id` int(11) DEFAULT NULL,
  `date_trans` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `message` varchar(100) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `notif` int(1) DEFAULT NULL,
  PRIMARY KEY (`tr_id`),
  KEY `con_user_id` (`user_id`),
  KEY `con_app_id` (`app_id`),
  KEY `con_admin_id` (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`tr_id`, `user_id`, `app_id`, `date_trans`, `message`, `admin_id`, `notif`) VALUES
(17, 1003, 24, '2017-10-21 23:08:36', 'i want this in my company', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `user_contact` varchar(15) DEFAULT NULL,
  `user_company` varchar(50) DEFAULT NULL,
  `user_email` varchar(25) DEFAULT NULL,
  `user_password` varchar(25) DEFAULT NULL,
  `date_reg` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_img` blob,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1008 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_address`, `user_contact`, `user_company`, `user_email`, `user_password`, `date_reg`, `user_img`) VALUES
(1001, 'Ransom', 'Talisay', NULL, 'MSCC', 'ransom@yahoo.com', 'ransom', '2017-10-15 10:23:55', 0x2e2e2f426f6f7473747261702f696d672f3535393534365f3737373635393039323237333539335f323831353431353838383138323236313033305f6e2e6a7067),
(1002, 'Ronald', 'Lahug', NULL, 'Tan Agency', 'ronald@yahoo.com', 'ronald', '2017-10-15 11:12:36', 0x2e2e2f426f6f7473747261702f696d672f322e6a7067),
(1003, 'Tan', 'mambaling', NULL, 'Tan Agency', 'tan@yahoo.com', 'tan', '2017-10-15 11:13:19', 0x2e2e2f426f6f7473747261702f696d672f332e6a7067),
(1004, 'Danly', 'Lahug', NULL, 'MSCC', 'danly@yahoo.com', 'danly', '2017-10-15 12:15:36', 0x2e2e2f426f6f7473747261702f696d672f6176617461722d6d696e69322e6a7067),
(1005, 'Ghe Mariefe', 'Biasong, Talisay City, Cebu', '09233026191', 'NBA', 'ghe@yahoo.com', 'ghe', '2017-10-16 08:14:01', 0x2e2e2f426f6f7473747261702f696d672f3535393534365f3737373635393039323237333539335f323831353431353838383138323236313033305f6e2e6a7067),
(1006, 'Ellemelem', 'mambaling', '0912352324', 'den security agency', 'ellem@yahoo.com', 'ellem', '2017-10-18 09:35:51', 0x2e2e2f426f6f7473747261702f696d672f617661746172312e6a7067),
(1007, NULL, 'taga amo', '102391234', NULL, 'banki@yahoo.com', 'banki', '2017-10-19 16:48:03', 0x2e2e2f426f6f7473747261702f696d672f31313231393038335f3932383332363837373230363831335f383838313330383032393032353533313930385f6e2e6a7067);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applicant_info`
--
ALTER TABLE `applicant_info`
  ADD CONSTRAINT `cons_user_id_app` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `con_tr_id` FOREIGN KEY (`tr_id`) REFERENCES `transaction` (`tr_id`) ON UPDATE CASCADE;

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `con_admin_id` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `con_app_id` FOREIGN KEY (`app_id`) REFERENCES `applicant_info` (`app_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `con_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
