<?php
	include_once("model/Model.php");
	class Controller{
		public	$model;
		public	function __construct(){		
			$this->model = new Model();
		}
		public function invoke(){
			 $this->Delete();
			 $this->Update();
			//  //$this->Retrieve();
			$this->Download();
			//$this->Transaction();
		    $this->Create();

		    $this->Logout();

		    $this->ValidateLogin();
			 
			
			$this->AUTH();

		}
		
		public function AUTH(){
			if(isset($_GET['auth'])){
				$auth = rtrim($_GET['auth'], '/');
				include 'view/Auth/'.$auth.'.php';
			}
			else if(isset($_GET['homepage'])){
				$this->Retrieve(); 	
			 }
			 else{
			
				include 'view/index.php';
				
			}	
			
		}
		//
		public function ValidateLogin(){
			if(isset($_POST['login_admin'])){
				$email = $_POST['email'];
				$password = $_POST['password'];
				$row = $this->model->ValidateAdminLogin(array($email,$password));
				if(count($row) > 1){
                setcookie("admin_id", $row['admin_id'], time() + 86400, "/"); // 86400 = 1 day
                header("Location: index.php?homepage=Home");
            }
            else{
                header('location: index.php?auth=Authentication');
            }
			}
		}
		public function Logout(){
			if(isset($_GET['logout'])){
				$this->model->Admin_Logout();
			}
		}
		//TRansaction
		public function Transaction(){
			if(isset($_GET['transaction_no'])){
				$tr_no = $_GET['transaction_no'];
				$admin_id = $_GET['admin_id'];
				$notif = $_GET['notif'];
				$this->model->UpdateNotifTransaction(array($admin_id,$notif,$tr_no));
				header("Location: index.php?homepage=Transaction");
				
			}
		}
		//
		public function Create(){
			
			//REGISTER STAFF
			if(isset($_POST['register_admin'])){
				
				$name = $_POST['name'];
				$address = $_POST['address'];
				$email = $_POST['email'];
				$password = $_POST['password'];

				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->RegisterAdmin(array($name,$address, $email, $password, $target_file));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?auth=Register");
			}

			// APplicants
			if(isset($_POST['register_applicant'])){
				$lname = $_POST['lname'];
				$fname = $_POST['fname'];
				$age = $_POST['age'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];

				$folder = "../Bootstrap/file/";
				$temp = explode(".", $_FILES["uploaded"]["name"]);
				$newfilename = round(microtime(true)).'.'. end($temp);
				$db_path ="$folder".$newfilename  ;
				$listtype = array(
				'.doc'=>'application/msword',
				'.docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'.rtf'=>'application/rtf',
				'.pdf'=>'application/pdf'); 
				if ( is_uploaded_file( $_FILES['uploaded']['tmp_name'] ) ){
					if($key = array_search($_FILES['uploaded']['type'],$listtype)){
						if (move_uploaded_file($_FILES['uploaded']  ['tmp_name'],"$folder".$newfilename)){
						echo "The file ". basename( $_FILES["uploaded"]["name"]). " has been uploaded.";
						}
					}
					else {
					echo "File Type Should Be .Docx or .Pdf or .Rtf Or .Doc";
					}
				}
				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->RegisterApplicant(array($lname, $fname,$age, $gender, $address, $contact, $target_file, $db_path,0,1));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?homepage=Post");
			}
			if(isset($_POST['send_message'])){
				$tr_id = $_POST['tr_id'];
				$sender = $_POST['sender'];
				$message = $_POST['message'];

				$this->model->SendMessages(array($tr_id,$sender,$message));
				header("Location: index.php?homepage=Transaction&transaction_no=$tr_id");
			}
		}
		public function Retrieve(){
				if(isset($_COOKIE['admin_id'])){
					date_default_timezone_set('Asia/Manila');
			        $admin_id=$_COOKIE['admin_id'];
			        
			         $name = $this->model->getAdminNameByID(array($admin_id));
			         $img = $this->model->getAdminImgByID(array($admin_id));
			         $trans_notif = $this->model->getTransactionsNotif();
			         $applicant = $this->model->getApplicant();
			         $unApprove = $this->model->getApplicantUpApprove();
			         $UVehicle = $this->model->GetVehicleWithUser();
			         $v_parts = $this->model->GetVehicleParts();
			         $NotifSubs = $this->model->GetSubscribeNotif();
			        if(isset($_GET['homepage'])){
			        	
			        	$homepage = null;
							$flag = rtrim($_GET['homepage'], '/');
							$page = array("Home","Profile", "Portfolio","Portfolio/Transaction","Portfolio/Update","UserProfile/Profile", "UserProfile/VehicleDetails", "Post","Transaction");
							for($i=0;$i<count($page);$i++){
								if($flag == $page[$i]){
									$homepage = $flag;
									if($homepage == "Portfolio"){
										include 'view/Homepage/adminHeader.php';
										include 'view/Homepage/Portfolio/'.$homepage.'.php';
										include 'view/Homepage/adminFooter.php';
									}
									elseif($homepage == "Transaction"){
										
										include 'view/Homepage/adminHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/adminFooter.php';
									}
									elseif($homepage == "Portfolio/Unhire"){
										$unhire = $this->model->getUnHireApplicant();
										include 'view/Homepage/adminHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/adminFooter.php';
									}
									elseif($homepage == "Transaction"){
										
										include 'view/Homepage/adminHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/adminFooter.php';
										
									}
									else{
										include 'view/Homepage/adminHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/adminFooter.php';
									}
										
									
								}
								else $homepage = $homepage;
						}
					 		
			 		
						 		
					}

				}
		    else{
		      header('location: index.php');
		    }				
		}
		public function Update(){
			//
			if(isset($_GET['app_status'])){
				$app_status = null;$app_id = $_GET['app_id'];
				if($_GET['app_status']==0 || $_GET['app_status']==null){
					$app_status=1;
				}
				else $app_status = 0;
				$this->model->UpdateAppStatus(array($app_status,$app_id));
				header("Location: index.php?homepage=Portfolio");
			}
			if(isset($_GET['approve'])){
				$approve = $_GET['approve'];
				$app_id = $_GET['app_id'];
				$this->model->ApproveApplicant(array($approve,$app_id));
				header("Location: index.php?homepage=Portfolio");
			}
			if(isset($_POST['update_applicant'])){
				$app_id = $_POST['app_id'];
				$lname = $_POST['lname'];
				$fname = $_POST['fname'];
				$age = $_POST['age'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];
				$status = $_POST['status'];

				$folder = "../Bootstrap/file/";
				$temp = explode(".", $_FILES["uploaded"]["name"]);
				$newfilename = round(microtime(true)).'.'. end($temp);
				$db_path ="$folder".$newfilename  ;
				$listtype = array(
				'.doc'=>'application/msword',
				'.docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'.rtf'=>'application/rtf',
				'.pdf'=>'application/pdf'); 
				if ( is_uploaded_file( $_FILES['uploaded']['tmp_name'] ) ){
					if($key = array_search($_FILES['uploaded']['type'],$listtype)){
						if (move_uploaded_file($_FILES['uploaded']  ['tmp_name'],"$folder".$newfilename)){
						echo "The file ". basename( $_FILES["uploaded"]["name"]). " has been uploaded.";
						}
					}
					else {
					echo "File Type Should Be .Docx or .Pdf or .Rtf Or .Doc";
					}
				}
				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
				$this->model->UpdateApplicant(array($lname, $fname,$age, $gender, $address, $contact, $target_file, $db_path,$status,$app_id));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?homepage=Portfolio");
			}
			//Change Email
			if(isset($_POST['change_staff_email'])){
		    $emp_id = $_POST['emp_id'];
			$email = $_POST['email'];
			$password = $_POST['password'];
		    $data = array($email,$emp_id);
		    $check_email = $this->model->CheckStaffEmail(array($email));
		    $check_pass = $this->model->CheckStaffPassword(array($emp_id, $password));
	        //setcookie("emp_email", $email, time() + 86400, "/");
	        if($check_email == NULL && $check_pass == "Checked"){
				$this->model->ChangeStaffEmail($data);
				setcookie("update", "ok", time() + 5, "/");
		        setcookie("emp_email", $email, time() + 86400, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
			else{
				setcookie("update", "used", time() + 5, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
		}
		//ChangePassword
		if(isset($_POST['change_staff_password'])){
		    $emp_id = $_POST['emp_id'];
			$password = $_POST['password'];
		    $data = array($password,$emp_id);
	        	$this->model->ChangeStaffPassword($data);
				setcookie("update", "ok", time() + 5, "/");
				header('Location: index.php?homepage=Profile&next=3');
			
		}
		if(isset($_POST['subscribe'])){
			$user_id = $_POST['user_id'];
			$this->model->SubscribeUser(array($user_id));
			header("LOCATION: index.php?homepage=UserProfile/Profile&user_id=$user_id");
		}
		if(isset($_POST['v_subscribe'])){
			$user_id = $_POST['user_id'];
			$v_id = $_POST['v_id'];
			$this->model->SubscribeVehicle(array($v_id));
			header("LOCATION: index.php?homepage=UserProfile/Profile&user_id=$user_id");
		}
		}
		public function Delete(){
			if(isset($_GET['id'])){
				$id=$_GET['id'];
					$this->model->DeleteApplicant(array($id));
					header('Location: index.php?homepage=Portfolio');	
			}
		}
		public function Download(){
			if(isset($_GET['file'])){
				$file = $_GET['file'];
				header('Content-Description: File Transfer');
			    header('Content-Type: application/force-download');
			    header("Content-Disposition: attachment; filename=\"" . basename($file) . "\";");
			    header('Content-Transfer-Encoding: binary');
			    header('Expires: 0');
			    header('Cache-Control: must-revalidate');
			    header('Pragma: public');
			    header('Content-Length: ' . filesize($file));
			    ob_clean();
			    flush();
			    readfile("Downloads/".$file); //showing the path to the server where the file is to be download
			    exit;
			}
		}
	}
?>