<!-- Portfolio Grid -->
    <section class="bg-light" id="" style="background-image: url('../Bootstrap/img/header-bg.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading" style="color: #fefefe;">Applicant</h2>
            <div class="btn btn-info">
            <?php
              if(isset($_GET['app_id'])){
              $p = $this->model->getPortfolio(array($_GET['app_id']));
                echo "<a href='index.php?approve=1&app_id=".$p['app_id']."' class='btn btn-success'>Approve</a> <a href='index.php?id=".$p['app_id']."' class='btn btn-danger'> Unapprove</a>";
                echo "<br><br><img src='".$p['app_img']."' width='400'><br><br>";
                echo "<div class='pull-right'>".$p['app_address']."</div>";
                echo "<div class='pull-left'>NAME: ".$p['app_lname'].", ".$p['app_fname']."</div>";
                echo "<br><div class='pull-right'> #".$p['app_contact']."</div>";

                echo "<div class='pull-left'>AGE: ".$p['app_age']." - ".$p['app_gender']."</div>";
                echo "<br><a class='btn btn-danger' style='width:100%;' href='index.php?file=".$p['app_resume']."'>Download Resume</a>";
              }
            
            ?>
            </div>
          </div>
        </div>
                  
        </div>
      </div>
    </section>
