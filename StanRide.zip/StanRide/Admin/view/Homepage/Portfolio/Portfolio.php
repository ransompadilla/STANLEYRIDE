<div class="container">
<?php
  if(count($UVehicle) > 0){

        foreach ($UVehicle as $v) {
            echo '
            <div style="margin-top: 10%; color: #aeaeae;">
            <div class="media" >
              <div class="media-left">
              <a href="index.php?homepage=UserProfile/Profile&user_id='.$v['user_id'].'">
                <img src="'.$v['user_img'].'" class="media-object" style="width:100px; height: 100px;">
              </a>
              </div>
              <div class="media-body" style="margin-left: 10px;">
              <a href="index.php?homepage=UserProfile/Profile&user_id='.$v['user_id'].'">
                <h5 class="media-heading" > '.$v['user_lname'].", ".$v['user_fname'].'</h5>
              </a>';
              if($v['subscribe'] != 1){
                echo '
                   <form method="POST">
                    <input type="hidden" name="user_id" value="'.$v['user_id'].'" />
                    <button type="submit" name="subscribe" class="float-right btn btn-primary"> Subscribe
                    </button>
                   </form>
                ';
              }
              else {
                echo '<button type="button" class="float-right btn btn-success"><span class="fa fa-check"> Subscribed</span>
                    </button>';
              }
             
                  $d = strtotime($v['v_create_date']);
                  $date = Date('F j, Y h:i A',$d);
                  echo "<p><i class='small text-muted'>".$date."</i><br>
                    Created a new ".$v['v_type']." ".$v['v_model']."
                  ";
                echo '</p>
              </div>
            </div>
            </div>
            <hr>
            <div class="container">
              <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-6">
                <a href="index.php?homepage=UserProfile/VehicleDetails&v_id='.$v['v_id'].'">
                  <img src="'.$v['v_img'].'" width="500"/>
                </a>
                  
                </div>
              </div>
            </div>

            <hr>
            ';
      
    }                 
       
  }
?>
</div>