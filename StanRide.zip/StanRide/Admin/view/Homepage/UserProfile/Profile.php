<?php
  if(isset($_GET['user_id'])){

    $userInfo = $this->model->getUserInformation(array($_GET['user_id']));
    $v_details = $this->model->GetMyVehicle($_GET['user_id']);
  }
  if(isset($_GET['v_id'])){
    
    $this->model->UpdateNotifVehicle(array(1, $_GET['v_id']));
  }
  if(isset($_GET['vp_id'])){
    $this->model->UpdateNotifSubs(array(0,$_GET['vp_id']));
  }
?>
<div style="margin-bottom: 8%">
</div>
      
      
    <!-- Team -->
    <section class="bg-light" id="team">
        
         <!--  <?php
        if($update == "ok"){
                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Updated..</div>';
                }
      ?> -->
      
      <div class="container">
       
        <div class="row">
          <div class="col-sm-6">

            <div class="team-member">
              <img class="mx-auto rounded-circle" src="<?php echo $userInfo['user_img'];?>" alt="">
              <h4><?php echo $userInfo['user_fname']." ".$userInfo['user_lname'];?></h4>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="">
              
              <p class="text-muted">
                  <?php echo "<strong>Gender:</strong> ".$userInfo['user_gender'];?> <br>
                  <?php echo "<strong>Job:</strong> ".$userInfo['user_work'];?> <br>
                  <?php echo "<strong>Contact:</strong> ".$userInfo['user_contact'];?> <br>
                  <?php echo "<strong>Address:</strong> ".$userInfo['user_address'];?> <br>
                  <?php echo "<strong>Email:</strong> ".$userInfo['user_email'];?> <br>
                  
              </p>
              <ul class="list-inline social-buttons">
                <li class="list-inline-item">
                  <?php
                    if($userInfo['subscribe'] > 0){
                      echo "<button class='btn btn-success'><span class='fa fa-check'>Subcribed</span></button>";
                    }
                    else{
                      echo '
                        <form method="POST">
                        <input type="hidden" name="user_id" value="'.$userInfo['user_id'].'" />
                        <button type="submit" name="subscribe" class="btn btn-primary"> Subscribe
                        </button>
                       </form>
                      ';
                    }
                  ?>
                </li>
                
              </ul>
            </div>
          </div>
    
        </div>
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <p class="large text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p>

            <div class="container" id="portfolio">
              
              <div class="row">
                <?php
                foreach ($v_details as $key => $value) {
                  echo '
                    <div class="col-md-4 col-sm-6 portfolio-item">
                  <a class="portfolio-link" href="index.php?homepage=UserProfile/VehicleDetails&v_id='.$value['v_id'].'">
                    <div class="portfolio-hover">
                      <div class="portfolio-hover-content">
                        <i class="fa fa-plus fa-3x"></i>
                      </div>
                    </div>
                    <img class="img-fluid" src="'.$value['v_img'].'" alt="'.$value['v_type'].'" style="width: auto; height:200px;">
                  </a>
                  <div class="portfolio-caption">
                    <h4>'.$value['v_type'].'</h4>
                    <p class="text-muted">'.$value['v_color'].'</p>
                  </div>';
                  if($value['v_subscribe'] > 0){
                      echo "<button class='btn btn-success'><span class='fa fa-check'>Subcribed</span></button>";
                    }
                    else{
                      echo '
                        <form method="POST">
                        <input type="hidden" name="user_id" value="'.$userInfo['user_id'].'" />
                        <input type="hidden" name="v_id" value="'.$value['v_id'].'" />
                        <button type="submit" name="v_subscribe" class="btn btn-primary"> Subscribe
                        </button>
                       </form>
                      ';
                    }
                  
                echo '</div>
                  ';
                }
                ?>
                
                
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
    <!-- Clients -->