<!-- <?php include "model/stack.php"; $stack = new Stacks();?> -->
<!DOCTYPE html>
<html>
<head>

	<?php include "model/Bootstrap.php"; ?>

    <script src="../Bootstrap/vendor/jquery/jquery.min.js"></script>
    <script src="../Bootstrap/vendor/bootstrap/js/bootstrap.min.js"></script>
    <style type="text/css">
      
    </style>
    <script type="text/javascript">
      $(document).ready(function(){
        $("#loading-page").load("index.php?homepage=Portfolio/Hire", function(responseTxt, statusTxt, xhr){
        });
        $('#unhire').click(function(){
          $("#loading-page").load("index.php?homepage=Portfolio/Unhire", function(responseTxt, statusTxt, xhr){
        });
          $('#hired').click(function(){
          $("#loading-page").load("index.php?homepage=Portfolio/Hire", function(responseTxt, statusTxt, xhr){
        });
        });
      });
    </script>
    <style type="text/css">
      #notif:hover{background-color: #d0d0d0;}
      #notif a {color: #000000; text-decoration: none;}
      #notif{padding:5px;}
    </style>
</head>
<body id="bg-light" >
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Stanley Ride</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?homepage=Portfolio">Portfolio</a>
            </li>
            <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#">
              <img class="img-circle" src="<?=$img;?>" width="20">
              <?=$name;?>
            </a>
            </li>
            <li class="nav-item">
            <div class="dropdown">
            
            
              <a class="nav-link js-scroll-trigger dropdown-toggle" data-toggle="dropdown" href="#"><?php 
              $count = 0;
              foreach ($UVehicle as $c_uv) {
                if($c_uv['v_notif'] == 0){
                 $count++;
                }
              }
              echo ( $count + count($NotifSubs));?><span class="fa fa-globe"></span>
              </a>
              <ul class="dropdown-menu" style="padding: 5px; width: 300px; margin-left: -200px;  overflow: auto; height: 500px;">

              <?php
                if(count($NotifSubs) > 0){
                  foreach ($NotifSubs as $nfs) {
                    date_default_timezone_set('Asia/Manila');
                    
                    $c_std = strtotime($nfs['change_date']);
                    $c_date = Date("m/j/Y",$c_std);
                   if($nfs['subscribe'] > 0){
                      echo '<a href="index.php?homepage=UserProfile/Profile&user_id='.$nfs['user_id'].'&vp_id='.$nfs['v_part_change_id'].'">
                            <li id="notif" style="background-color:#c0c0c0;">
                      
                              <img src="'.$nfs['user_img'].'" style="width:30px; height:30px;">
                              <i class="text-muted">'.$nfs['user_lname'].', '.$nfs['user_fname'].'</i>
                              <br>
                              <i style="margin-left:0px;" class="small text-muted"> '.$nfs['description'].' '.$nfs['v_part_desc'].' on '.$nfs['v_type'].' - '.$nfs['v_model'].' in '.$nfs['v_service_desc'].' at '.$c_date.' </i>
                             <span class="float-right">&nbsp;&nbsp;&nbsp;<img src="'.$nfs['v_img'].'" style="width:40px; height:40px;"></span>
                      
                            </li>
                            </a><hr>';
                    
                    }
                  }
                }
                if(count($UVehicle) > 0){
                  foreach ($UVehicle as $v) {
                    date_default_timezone_set('Asia/Manila');
                    
                    $v_std = strtotime($v['v_create_date']);
                    $v_date = Date("m/j/Y",$v_std);
                    if($v['v_notif'] == 0){
                      echo '<a href="index.php?homepage=UserProfile/Profile&user_id='.$v['user_id'].'&v_id='.$v['v_id'].'">
                            <li id="notif">
                      
                              <img src="'.$v['user_img'].'" style="width:30px; height:30px;">
                              <i class="text-muted">'.$v['user_lname'].', '.$v['user_fname'].'</i>
                              <br>
                              <i style="margin-left:0px;" class="small text-muted"> Created a new '.$v['v_type'].' - '.$v['v_model'].' at '.$v_date.' </i>
                             <span class="float-right">&nbsp;&nbsp;&nbsp;<img src="'.$v['v_img'].'" style="width:40px; height:40px;"></span>
                      
                            </li>
                            </a><hr>';
                    
                    }
                  } 
                }
              ?>
              </ul>
            </div>
            </li>

            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="index.php?logout=1">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
